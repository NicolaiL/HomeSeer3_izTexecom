﻿Imports System.Text
Imports System.IO
Imports System.Threading
Imports System.Web
Imports System
Imports HomeSeerAPI
Imports Scheduler

Public Class plugin
    Dim sConfigPage As String = "izTexecom_Config"
    Dim sStatusPage As String = "izTexecom_Status"
    Dim sHelpPage As String = "http://home.indigozest.net/FTP/HomeSeer3/izTexecom/izTexecom_manual.pdf"
    Dim ConfigPage As New web_config(sConfigPage)
    Dim StatusPage As New web_status(sStatusPage)
    Dim WebPage As Object

    Dim actions As New hsCollection
    Dim action As New action
    Dim triggers As New hsCollection
    Dim trigger As New trigger

    Dim Commands As New hsCollection

    Const Pagename = "Events"

#Region "Action/Trigger/Device Processes"
#Region "Device Interface"

    Public Function ConfigDevice(ref As Integer, user As String, userRights As Integer, newDevice As Boolean) As String

        ' Next line added for now to avoid  the pop up in the Device Creation Screen
        Return ""

        ' Dim dv As Scheduler.Classes.DeviceClass = Nothing
        ' Dim stb As New StringBuilder
        ' Dim ddHouseCode As New clsJQuery.jqDropList("HouseCode", "", False)
        ' Dim ddUnitCode As New clsJQuery.jqDropList("DeviceCode", "", False)
        ' Dim bSave As New clsJQuery.jqButton("Save", "Done", "DeviceUtility", True)
        ' Dim HouseCode As String = ""
        ' Dim Devicecode As String = ""
        ' Dim Sample As SampleClass
        '
        'dv = hs.GetDeviceByRef(ref)
        '
        'Dim PED As clsPlugExtraData = dv.PlugExtraData_Get(hs)
        '
        'Sample = PEDGet(PED, IFACE_NAME)
        '
        'If Sample Is Nothing Then
        '' Set the defaults
        'Sample = New SampleClass
        'InitHSDevice(dv)
        'Sample.Housecode = "A"
        'Sample.DeviceCode = "1"
        'PEDAdd(PED, "Sample", Sample)
        'dv.PlugExtraData_Set(hs) = PED
        'End If
        '
        'HouseCode = Sample.Housecode
        'Devicecode = Sample.DeviceCode
        '
        'For Each l In "ABCDEFGHIJKLMNOP"
        'ddHouseCode.AddItem(l, l, l = HouseCode)
        'Next
        '
        'For i = 1 To 16
        'ddUnitCode.AddItem(i.ToString, i.ToString, i.ToString = Devicecode)
        'Next
        '
        'Try
        'stb.Append("<form id='frmSample' name='SampleTab' method='Post'>")
        'stb.Append(" <table border='0' cellpadding='0' cellspacing='0' width='610'>")
        'stb.Append("  <tr><td colspan='4' align='Center' style='font-size:10pt; height:30px;' nowrap>Select a Housecode and Unitcode that matches one of the devices HomeSeer will be communicating with.</td></tr>")
        'stb.Append("  <tr>")
        'stb.Append("   <td nowrap class='tablecolumn' align='center' width='70'>House<br>Code</td>")
        'stb.Append("   <td nowrap class='tablecolumn' align='center' width='70'>Unit<br>Code</td>")
        'stb.Append("   <td nowrap class='tablecolumn' align='center' width='200'>&nbsp;</td>")
        'stb.Append("  </tr>")
        'stb.Append("  <tr>")
        'stb.Append("   <td class='tablerowodd' align='center'>" & ddHouseCode.Build & "</td>")
        'stb.Append("   <td class='tablerowodd' align='center'>" & ddUnitCode.Build & "</td>")
        'stb.Append("   <td class='tablerowodd' align='left'>" & bSave.Build & "</td>")
        'stb.Append("  </tr>")
        'stb.Append(" </table>")
        'stb.Append("</form>")
        'Return stb.ToString
        'Catch
        'Return Err.Description
        'End Try
    End Function

    Public Function ConfigDevicePost(ref As Integer, data As String, user As String, userRights As Integer) As Enums.ConfigDevicePostReturn

        ' Added for now to avoid  the pop up in the Device Creation Screen
        Return Enums.ConfigDevicePostReturn.DoneAndCancel

        'Dim dv As Scheduler.Classes.DeviceClass = Nothing
        'Dim parts As Collections.Specialized.NameValueCollection
        'Dim PED As clsPlugExtraData
        'Dim ReturnValue As Integer = Enums.ConfigDevicePostReturn.DoneAndCancel
        'Dim Sample As SampleClass
        '
        'Try
        'parts = HttpUtility.ParseQueryString(data)
        '
        'dv = hs.GetDeviceByRef(ref)
        'PED = dv.PlugExtraData_Get(hs)
        'Sample = PEDGet(PED, "Sample")
        'If Sample Is Nothing Then
        'InitHSDevice(dv)
        'End If
        '
        'Sample.Housecode = parts("HouseCode")
        'Sample.DeviceCode = parts("DeviceCode")
        '
        'PED = dv.PlugExtraData_Get(hs)
        'PEDAdd(PED, "Sample", Sample)
        'dv.PlugExtraData_Set(hs) = PED
        'hs.SaveEventsDevices()
        '
        'Return ReturnValue
        'Catch ex As Exception
        '
        'End Try
        'Return ReturnValue
    End Function

    Public Sub SetIOMulti(colSend As System.Collections.Generic.List(Of HomeSeerAPI.CAPI.CAPIControl))

        Dim CC As CAPIControl
        Dim dv As Scheduler.Classes.DeviceClass = Nothing

        Dim CFRoot As Integer = 0

        For Each CC In colSend
            dv = hs.GetDeviceByRef(CC.Ref)
            Dim AdrLookup As String = dv.Address(Nothing)
            AdrLookup = Right(AdrLookup, AdrLookup.Length - IFACE_NAME.Length)
            Dim Index As String = Right(AdrLookup, Len(AdrLookup) - InStr(AdrLookup, "-") - 1)
            Select Case AdrLookup
                Case _RootAddress
                    Select Case CC.ControlValue
                        Case eRootStatus.ArmStatus
                            AstatusInProgress = True
                            SendTexecomCommand_Crestron("ASTATUS")
                        Case Else
                            WriteLog(ErrorLog, "SetIOMulti called with invalid parameters, DeviceRef: " & dv.Ref(Nothing) & " Device: " & AdrLookup & " Value: " & CC.ControlValue, 0)
                    End Select
                Case _LCDAddress
                    Select Case CC.ControlValue
                        Case eLCD.ViewStatus
                            SendTexecomCommand_Crestron("LSTATUS")
                        Case 1 To _SendKeyPressCmd.Length - 1
                            SendTexecomCommand_Crestron("KEY" & _SendKeyPressCmd(CC.ControlValue), False)
                            SendTexecomCommand_Crestron("LSTATUS")
                        Case Else
                            WriteLog(ErrorLog, "SetIOMulti called with invalid parameters, DeviceRef: " & dv.Ref(Nothing) & " Device: " & AdrLookup & " Value: " & CC.ControlValue, 0)
                    End Select
                Case _AreaAddress & "001" To _AreaAddress & "999"
                    LastSimpleRef = dv.Ref(Nothing)
                    Select Case CC.ControlValue
                        Case eAreaStatus.Arm
                            WriteLog(DebugLog, "Arming Area: " & AdrLookup, 5)
                            Simple_ArmArea(Val(Index))
                        Case eAreaStatus.Disarm
                            WriteLog(DebugLog, "Disarming Area: " & AdrLookup, 5)
                            Simple_DisarmArea(Val(Index))
                        Case eAreaStatus.PartArm
                            WriteLog(DebugLog, "Part Arming Area: " & AdrLookup, 5)
                            Simple_PartArmArea(Val(Index))
                        Case eAreaStatus.Reset
                            WriteLog(DebugLog, "Reset Area: " & AdrLookup, 5)
                            Simple_ResetArea(Val(Index))
                    End Select
                Case _PanelTimeAddress
                    Select Case CC.ControlValue
                        Case ePanelTimeDevice.ReadTime
                            WriteLog(DebugLog, "Reading Panel Time", 5)
                            Simple_ReadPanelTime()
                        Case ePanelTimeDevice.SetTime
                            WriteLog(DebugLog, "Setting Panel Time", 5)
                            Simple_SetPanelTime()
                    End Select
                Case _SystemVoltageAddress, _SystemCurrentAddress, _BatteryVoltageAddress, _BatteryCurrentAddress
                    Select Case CC.ControlValue
                        Case eVoltages.Read
                            WriteLog(DebugLog, "Reading Voltages and Currents", 5)
                            Simple_ReadVoltages()
                    End Select
                Case _OutputX10Address & "1" To _OutputX10Address & "8"
                    LastSimpleRef = dv.Ref(Nothing)
                    Index = Right(Index, 1)
                    Select Case CC.ControlValue
                        Case eX10.On
                            WriteLog(DebugLog, "Setting X10 Ouput #" & Index & " to On", 5)
                            Simple_X10On(Val(Index))
                        Case eX10.Off
                            WriteLog(DebugLog, "Setting X10 Ouput #" & Index & " to Off", 5)
                            Simple_X10Off(Val(Index))
                        Case Else
                            WriteLog(ErrorLog, "SetIOMulti called with invalid parameters, DeviceRef: " & dv.Ref(Nothing) & " Device: " & AdrLookup & " Value: " & CC.ControlValue, 0)
                    End Select
                Case _PanelLogAddress
                    Select Case CC.ControlValue
                        Case ePanelLog.Down
                            _LogDisplayIndex -= 1
                            If _LogDisplayIndex < 0 Then _LogDisplayIndex = _PanelLogMessages.Length - 1
                            UpdateHSDeviceString(PanelLogAddress, (_LogDisplayIndex + 1).ToString & ": " & _PanelLogMessages(_LogDisplayIndex))
                        Case ePanelLog.Up
                            _LogDisplayIndex += 1
                            If _LogDisplayIndex > _PanelLogMessages.Length - 1 Then _LogDisplayIndex = 0
                            UpdateHSDeviceString(PanelLogAddress, (_LogDisplayIndex + 1).ToString & ": " & _PanelLogMessages(_LogDisplayIndex))
                        Case ePanelLog.Read
                            _LogReadFromTimer = False
                            Simple_PanelLogRead()
                    End Select

                    ' Case _ZoneAddress ' No buttons on Zone devices yet
            End Select
        Next
    End Sub

#End Region

#Region "Action Properties"

    Sub SetActions()
        Dim o As Object = Nothing
        If actions.Count = 0 Then
            actions.Add(o, "Send Command")
        End If
    End Sub

    Function ActionCount() As Integer
        SetActions()
        Return actions.Count
        'Return 0
    End Function

    ReadOnly Property ActionName(ByVal ActionNumber As Integer) As String
        Get
            SetActions()
            If ActionNumber > 0 AndAlso ActionNumber <= actions.Count Then
                Return IFACE_NAME & ": " & actions.Keys(ActionNumber - 1)
            Else
                Return ""
            End If
        End Get
    End Property

    Function ActionReferencesDevice(ByVal ActInfo As IPlugInAPI.strTrigActInfo, ByVal dvRef As Integer) As Boolean

        hs.WriteLog("HELP!!", "In ActionReferencesDevice")
        Console.WriteLine("HELP!!  -  In ActionReferencesDevice")
        'Dim Act As MyAct = Nothing
        'Try
        'Act = GetAction(ActInfo)
        'Catch ex As Exception
        'Act = Nothing
        'End Try
        'If Act Is Nothing Then Return False
        'Return Act.Devices.Contains(dvRef)
        Return False
    End Function

#End Region

#Region "Trigger Proerties"

    Sub SetTriggers()
        'Dim o As Object = Nothing
        'If triggers.Count = 0 Then
        ' triggers.Add(o, "Recieve Command")
        ' End If
    End Sub

    Public ReadOnly Property HasTriggers() As Boolean
        Get
            '    SetTriggers()
            '    Return IIf(triggers.Count > 0, True, False)
            Return False
        End Get
    End Property

    Public Function TriggerCount() As Integer
        'SetTriggers()
        'Return triggers.Count
        Return 0
    End Function

    Public ReadOnly Property SubTriggerCount(ByVal TriggerNumber As Integer) As Integer
        Get
            '    Dim trigger As trigger
            '    If ValidTrig(TriggerNumber) Then
            '        trigger = triggers(TriggerNumber - 1)
            '        If Not (trigger Is Nothing) Then
            '            Return trigger.Count
            '        Else
            '            Return 0
            '        End If
            '    Else
            Return 0
            '    End If
        End Get
    End Property

    Public ReadOnly Property TriggerName(ByVal TriggerNumber As Integer) As String
        Get
            'If Not ValidTrig(TriggerNumber) Then
            Return ""
            'Else
            'Return IFACE_NAME & ": " & triggers.Keys(TriggerNumber - 1)
            'End If
        End Get
    End Property

    Public ReadOnly Property SubTriggerName(ByVal TriggerNumber As Integer, ByVal SubTriggerNumber As Integer) As String
        Get
            'Dim trigger As trigger
            'If ValidSubTrig(TriggerNumber, SubTriggerNumber) Then
            ' trigger = triggers(TriggerNumber)
            ' Return IFACE_NAME & ": " & trigger.Keys(SubTriggerNumber)
            ' Else
            Return ""
            'End If
        End Get
    End Property

    Friend Function ValidTrig(ByVal TrigIn As Integer) As Boolean
        SetTriggers()
        'If TrigIn > 0 AndAlso TrigIn <= triggers.Count Then
        '    Return True
        'End If
        Return False
    End Function

    Public Function ValidSubTrig(ByVal TrigIn As Integer, ByVal SubTrigIn As Integer) As Boolean
        'Dim trigger As trigger = Nothing
        'If TrigIn > 0 AndAlso TrigIn <= triggers.Count Then
        ' trigger = triggers(TrigIn)
        ' If Not (trigger Is Nothing) Then
        ' If SubTrigIn > 0 AndAlso SubTrigIn <= trigger.Count Then Return True
        ' End If
        ' End If
        Return False
    End Function

#End Region

#Region "Action Interface"

    Public Function HandleAction(ByVal ActInfo As IPlugInAPI.strTrigActInfo) As Boolean
        Dim Housecode As String = ""
        Dim DeviceCode As String = ""
        Dim Command As String = ""
        Dim UID As String
        UID = ActInfo.UID.ToString

        Try
            If Not (ActInfo.DataIn Is Nothing) Then
                DeSerializeObject(ActInfo.DataIn, action)
            Else
                Return False
            End If
            For Each sKey In action.Keys
                Select Case True
                    Case InStr(sKey, "Housecodes_" & UID) > 0
                        Housecode = action(sKey)
                    Case InStr(sKey, "DeviceCodes_" & UID) > 0
                        DeviceCode = action(sKey)
                    Case InStr(sKey, "Commands_" & UID) > 0
                        Command = action(sKey)
                End Select
            Next

            'SendCommand(Housecode, DeviceCode, Command)

        Catch ex As Exception
            hs.WriteLog(IFACE_NAME, "Error executing action: " & ex.Message)
        End Try
        Return True
    End Function

    Public Function ActionConfigured(ByVal ActInfo As IPlugInAPI.strTrigActInfo) As Boolean
        Dim Configured As Boolean = False
        Dim sKey As String
        Dim itemsConfigured As Integer = 0
        Dim itemsToConfigure As Integer = 3
        Dim UID As String
        UID = ActInfo.UID.ToString

        If Not (ActInfo.DataIn Is Nothing) Then
            DeSerializeObject(ActInfo.DataIn, action)
            For Each sKey In action.Keys
                Select Case True
                    Case InStr(sKey, "Housecodes_" & UID) > 0 AndAlso action(sKey) <> ""
                        itemsConfigured += 1
                    Case InStr(sKey, "DeviceCodes_" & UID) > 0 AndAlso action(sKey) <> ""
                        itemsConfigured += 1
                    Case InStr(sKey, "Commands_" & UID) > 0 AndAlso action(sKey) <> ""
                        itemsConfigured += 1
                End Select
            Next
            If itemsConfigured = itemsToConfigure Then Configured = True
        End If
        Return Configured
    End Function

    Public Function ActionBuildUI(ByVal sUnique As String, ByVal ActInfo As HomeSeerAPI.IPlugInAPI.strTrigActInfo) As String
        Dim UID As String
        UID = ActInfo.UID.ToString
        Dim stb As New StringBuilder

        Dim Group As String = ""
        Dim Colour As String = ""
        Dim Program As String = ""
        Dim Value As String = ""

        'Dim Housecode As String = ""
        'Dim DeviceCode As String = ""
        'Dim Command As String = ""

        Dim dd1 As New clsJQuery.jqDropList("Group_" & UID & sUnique, Pagename, True)
        dd1.autoPostBack = True
        dd1.AddItem("--Please Select--", "", False)

        Dim dd2 As New clsJQuery.jqDropList("Colour_" & UID & sUnique, Pagename, True)
        dd2.autoPostBack = True
        dd2.AddItem("--Please Select--", "", False)

        Dim dd3 As New clsJQuery.jqDropList("Program_" & UID & sUnique, Pagename, True)
        dd3.autoPostBack = True
        dd3.AddItem("--Please Select--", "", False)

        'Dim dd1 As New clsJQuery.jqDropList("DeviceCodes_" & UID & sUnique, Pagename, True)
        'Dim dd2 As New clsJQuery.jqDropList("Commands_" & UID & sUnique, Pagename, True)

        Dim sKey As String

        'dd2.autoPostBack = True
        'dd2.AddItem("--Please Select--", "", False)

        If Not (ActInfo.DataIn Is Nothing) Then
            DeSerializeObject(ActInfo.DataIn, action)
        Else 'new event, so clean out the action object
            action = New action
        End If

        For Each sKey In action.Keys
            Select Case True
                Case InStr(sKey, "Group_" & UID) > 0
                    Group = action(sKey)
                Case InStr(sKey, "Colour_" & UID) > 0
                    Colour = action(sKey)
                Case InStr(sKey, "Program_" & UID) > 0
                    Program = action(sKey)
                Case InStr(sKey, "Value_" & UID) > 0
                    Value = action(sKey)
            End Select
        Next

        dd1.AddItem("All", "All", "All" = Group)
        For i = 1 To 7
            dd1.AddItem(i.ToString, i.ToString, (i.ToString = Group))
        Next

        dd2.AddItem("Red", "Red", "Red" = Colour)
        dd2.AddItem("Green", "Green", "Green" = Colour)
        dd2.AddItem("Blue", "Blue", "Blue" = Colour)

        For i = 0 To 7
            dd3.AddItem(i.ToString, i.ToString, (i.ToString = Program))
        Next
        dd3.AddItem("9", "9", ("9" = Program))

        Dim dd4 As New clsJQuery.jqTextBox("Value_" & UID & sUnique, "", Value, Pagename, 3, True)

        'For Each C In "ABCDEFGHIJKLMNOP"
        ' dd.AddItem(C, C, (C = Housecode))
        ' Next

        stb.Append("Select Group:")
        stb.Append(dd1.Build)

        'dd1.AddItem("All", "All", ("All" = DeviceCode))
        'For i = 1 To 16
        '    dd1.AddItem(i.ToString, i.ToString, (i.ToString = DeviceCode))
        'Next

        Select Case ActInfo.TANumber
            Case 1
                stb.Append("Select Colour:")
                stb.Append(dd2.Build)

                stb.Append("Input Value:")
                stb.Append(dd4.Build)
            Case 2
                stb.Append("Input Value:")
                stb.Append(dd4.Build)
            Case 3
                stb.Append("Select Program:")
                stb.Append(dd3.Build)
            Case Else
                WriteLog(izStd.ErrorLog, "Invalid Action Number", 0)
        End Select


        'stb.Append("Select Unit Code:")
        'stb.Append(dd1.Build)

        'For Each item In Commands.Keys
        ' dd2.AddItem(Commands(item), item, (item = Command))
        ' Next

        'stb.Append("Select Command:")
        'stb.Append(dd2.Build)

        Return stb.ToString
    End Function

    Public Function ActionProcessPostUI(ByVal PostData As Collections.Specialized.NameValueCollection, _
                                        ByVal ActInfo As IPlugInAPI.strTrigActInfo) As IPlugInAPI.strMultiReturn

        Dim Ret As New HomeSeerAPI.IPlugInAPI.strMultiReturn
        Dim UID As String
        UID = ActInfo.UID.ToString

        Ret.sResult = ""
        ' We cannot be passed info ByRef from HomeSeer, so turn right around and return this same value so that if we want, 
        '   we can exit here by returning 'Ret', all ready to go.  If in this procedure we need to change DataOut or TrigInfo,
        '   we can still do that.
        Ret.DataOut = ActInfo.DataIn
        Ret.TrigActInfo = ActInfo

        If PostData Is Nothing Then Return Ret
        If PostData.Count < 1 Then Return Ret

        If Not (ActInfo.DataIn Is Nothing) Then
            DeSerializeObject(ActInfo.DataIn, action)
        End If

        Dim parts As Collections.Specialized.NameValueCollection

        Dim sKey As String

        parts = PostData

        Try
            For Each sKey In parts.Keys
                If sKey Is Nothing Then Continue For
                If String.IsNullOrEmpty(sKey.Trim) Then Continue For
                Select Case True
                    Case InStr(sKey, "Group_" & UID) > 0, InStr(sKey, "Colour_" & UID) > 0, InStr(sKey, "Value_" & UID) > 0, InStr(sKey, "Program_" & UID) > 0
                        action.Add(CObj(parts(sKey)), sKey)
                End Select
            Next
            If Not SerializeObject(action, Ret.DataOut) Then
                Ret.sResult = IFACE_NAME & " Error, Serialization failed. Signal Action not added."
                Return Ret
            End If
        Catch ex As Exception
            Ret.sResult = "ERROR, Exception in Action UI of " & IFACE_NAME & ": " & ex.Message
            Return Ret
        End Try

        ' All OK
        Ret.sResult = ""
        Return Ret
    End Function

    Public Function ActionFormatUI(ByVal ActInfo As IPlugInAPI.strTrigActInfo) As String
        Dim stb As New StringBuilder
        Dim sKey As String
        Dim Housecode As String = ""
        Dim DeviceCode As String = ""
        Dim Command As String = ""
        Dim UID As String
        UID = ActInfo.UID.ToString

        If Not (ActInfo.DataIn Is Nothing) Then
            DeSerializeObject(ActInfo.DataIn, action)
        End If

        For Each sKey In action.Keys
            Select Case True
                Case InStr(sKey, "Housecodes_" & UID) > 0
                    Housecode = action(sKey)
                Case InStr(sKey, "DeviceCodes_" & UID) > 0
                    DeviceCode = action(sKey)
                Case InStr(sKey, "Commands_" & UID) > 0
                    Command = action(sKey)
            End Select
        Next

        stb.Append(" the system will execute the " & Commands(Command) & " command ")
        stb.Append("on Housecode " & Housecode & " ")
        If DeviceCode = "ALL" Then
            stb.Append("for all Unitcodes")
        Else
            stb.Append("for Unitcode " & DeviceCode)
        End If

        Return stb.ToString
    End Function

#End Region

#Region "Trigger Interface"

    Public ReadOnly Property TriggerConfigured(ByVal TrigInfo As HomeSeerAPI.IPlugInAPI.strTrigActInfo) As Boolean
        Get
            Dim Configured As Boolean = False
            Dim sKey As String
            Dim itemsConfigured As Integer = 0
            Dim itemsToConfigure As Integer = 3
            Dim UID As String
            UID = TrigInfo.UID.ToString

            If Not (TrigInfo.DataIn Is Nothing) Then
                DeSerializeObject(TrigInfo.DataIn, trigger)
                For Each sKey In trigger.Keys
                    Select Case True
                        Case InStr(sKey, "Housecodes_" & UID) > 0 AndAlso trigger(sKey) <> ""
                            itemsConfigured += 1
                        Case InStr(sKey, "DeviceCodes_" & UID) > 0 AndAlso trigger(sKey) <> ""
                            itemsConfigured += 1
                        Case InStr(sKey, "Commands_" & UID) > 0 AndAlso trigger(sKey) <> ""
                            itemsConfigured += 1
                    End Select
                Next
                If itemsConfigured = itemsToConfigure Then Configured = True
            End If
            Return Configured
        End Get
    End Property

    Public Function TriggerBuildUI(ByVal sUnique As String, ByVal TrigInfo As HomeSeerAPI.IPlugInAPI.strTrigActInfo) As String
        Dim UID As String
        UID = TrigInfo.UID.ToString
        Dim stb As New StringBuilder
        Dim Housecode As String = ""
        Dim DeviceCode As String = ""
        Dim Command As String = ""
        Dim dd As New clsJQuery.jqDropList("Housecodes_" & UID & sUnique, Pagename, True)
        Dim dd1 As New clsJQuery.jqDropList("DeviceCodes_" & UID & sUnique, Pagename, True)
        Dim dd2 As New clsJQuery.jqDropList("Commands_" & UID & sUnique, Pagename, True)
        Dim sKey As String

        dd.autoPostBack = True
        dd.AddItem("--Please Select--", "", False)
        dd1.autoPostBack = True
        dd1.AddItem("--Please Select--", "", False)
        dd2.autoPostBack = True
        dd2.AddItem("--Please Select--", "", False)

        If Not (TrigInfo.DataIn Is Nothing) Then
            DeSerializeObject(TrigInfo.DataIn, trigger)
        Else 'new event, so clean out the trigger object
            trigger = New trigger
        End If

        For Each sKey In trigger.Keys
            Select Case True
                Case InStr(sKey, "Housecodes_" & UID) > 0
                    Housecode = trigger(sKey)
                Case InStr(sKey, "DeviceCodes_" & UID) > 0
                    DeviceCode = trigger(sKey)
                Case InStr(sKey, "Commands_" & UID) > 0
                    Command = trigger(sKey)
            End Select
        Next

        For Each C In "ABCDEFGHIJKLMNOP"
            dd.AddItem(C, C, (C = Housecode))
        Next

        stb.Append("Select House Code:")
        stb.Append(dd.Build)

        dd1.AddItem("All", "All", ("All" = DeviceCode))
        For i = 1 To 16
            dd1.AddItem(i.ToString, i.ToString, (i.ToString = DeviceCode))
        Next

        stb.Append("Select Unit Code:")
        stb.Append(dd1.Build)

        For Each item In Commands.Keys
            dd2.AddItem(Commands(item), item, (item = Command))
        Next

        stb.Append("Select Command:")
        stb.Append(dd2.Build)


        Return stb.ToString
    End Function

    Public Function TriggerProcessPostUI(ByVal PostData As System.Collections.Specialized.NameValueCollection, _
                                                     ByVal TrigInfo As HomeSeerAPI.IPlugInAPI.strTrigActInfo) As HomeSeerAPI.IPlugInAPI.strMultiReturn
        Dim Ret As New HomeSeerAPI.IPlugInAPI.strMultiReturn
        Dim UID As String
        UID = TrigInfo.UID.ToString

        Ret.sResult = ""
        ' We cannot be passed info ByRef from HomeSeer, so turn right around and return this same value so that if we want, 
        '   we can exit here by returning 'Ret', all ready to go.  If in this procedure we need to change DataOut or TrigInfo,
        '   we can still do that.
        Ret.DataOut = TrigInfo.DataIn
        Ret.TrigActInfo = TrigInfo

        If PostData Is Nothing Then Return Ret
        If PostData.Count < 1 Then Return Ret

        If Not (TrigInfo.DataIn Is Nothing) Then
            DeSerializeObject(TrigInfo.DataIn, trigger)
        End If

        Dim parts As Collections.Specialized.NameValueCollection

        Dim sKey As String

        parts = PostData
        Try
            For Each sKey In parts.Keys
                If sKey Is Nothing Then Continue For
                If String.IsNullOrEmpty(sKey.Trim) Then Continue For
                Select Case True
                    Case InStr(sKey, "Housecodes_" & UID) > 0, InStr(sKey, "DeviceCodes_" & UID) > 0, InStr(sKey, "Commands_" & UID) > 0
                        trigger.Add(CObj(parts(sKey)), sKey)
                End Select
            Next
            If Not SerializeObject(trigger, Ret.DataOut) Then
                Ret.sResult = IFACE_NAME & " Error, Serialization failed. Signal Trigger not added."
                Return Ret
            End If
        Catch ex As Exception
            Ret.sResult = "ERROR, Exception in Trigger UI of " & IFACE_NAME & ": " & ex.Message
            Return Ret
        End Try

        ' All OK
        Ret.sResult = ""
        Return Ret
    End Function

    Public Function TriggerFormatUI(ByVal TrigInfo As HomeSeerAPI.IPlugInAPI.strTrigActInfo) As String
        Dim stb As New StringBuilder
        Dim sKey As String
        Dim Housecode As String = ""
        Dim DeviceCode As String = ""
        Dim Command As String = ""
        Dim UID As String
        UID = TrigInfo.UID.ToString

        If Not (TrigInfo.DataIn Is Nothing) Then
            DeSerializeObject(TrigInfo.DataIn, trigger)
        End If

        For Each sKey In trigger.Keys
            Select Case True
                Case InStr(sKey, "Housecodes_" & UID) > 0
                    Housecode = trigger(sKey)
                Case InStr(sKey, "DeviceCodes_" & UID) > 0
                    DeviceCode = trigger(sKey)
                Case InStr(sKey, "Commands_" & UID) > 0
                    Command = trigger(sKey)
            End Select
        Next

        stb.Append(" the system detected the " & Commands(Command) & " command ")
        stb.Append("on Housecode " & Housecode & " ")
        If DeviceCode = "ALL" Then
            stb.Append("from a Unitcode")
        Else
            stb.Append("from Unitcode " & DeviceCode)
        End If

        Return stb.ToString
    End Function

#End Region

#End Region

#Region "HomeSeer-Required Functions"

    Function name() As String
        name = IFACE_NAME
    End Function

    Public Function AccessLevel() As Integer
        AccessLevel = 2
    End Function

#End Region

#Region "Init"
    Public Function InitIO(ByVal port As String) As String
        '' Add date check here to exit PlugIn if this is beyond certain date
        '' Use OA formate to avoid issues with different culture settings
        '' Use separate code to calculate this date if it changes:
        ''Dim ExpiryDate As New System.DateTime(2015, 9, 30, 0, 0, 0)
        ''Dim MyDate As Double
        ''MyDate = ExpiryDate.ToOADate()
        'Const ValidUntilDate As Double = 42277 ' Equate to 30/9/2015
        'Dim ValidUntilValue As Date = DateTime.FromOADate(ValidUntilDate)

        'If Date.Now > ValidUntilValue Then
        '    hs.WriteLog(IFACE_NAME & " Error", "Trial has expired. Please buy the full product")
        '    Console.WriteLine(IFACE_NAME & " Error", "Trial has expired. Please buy the full product")
        '    Return "Trial has expired. Please buy the full product"
        'Else
        '    hs.WriteLog(IFACE_NAME, "This plug-in is a BETA VERSION ONLY and must not be used beyond the inital beta period, expiring " & ValidUntilValue.ToString("dd MMMM yyyy"))
        'End If

        Dim ReturnVal As String = ""

        Dim o As Object = Nothing
        RegisterWebPage(sConfigPage, , , True) ' NICOLAI FIX THESE ONES
        'RegisterWebPage(sStatusPage)

        ' Register Help Page
        RegisterWebPage(sHelpPage, "Help", , False)

        'if more than 1 action/trigger is needed, or if subactions/triggers are needed, then add them all here
        'actions.Add(o, "Change Increment")
        'actions.Add(o, "Change Track")
        'actions.Add(o, "Select Program")
        'triggers.Add(o, "Trigger1")
        'triggers.Add(o, "Trigger2")

        ' Read INI settings and initialise standard indigozest functions
        ReturnVal = IniPlugIn()
        If ReturnVal <> "" Then
            WriteLog(ErrorLog, ReturnVal, 0)
            Return ReturnVal
        End If

        ReturnVal = izTexecom.izInit(port)
        If ReturnVal <> "" Then
            WriteLog(ErrorLog, ReturnVal, 0)
            Return ReturnVal
        End If

        'LoadCommands()

        Return ""
    End Function

    Public Sub ShutdownIO()
        Try
            Try
                hs.SaveEventsDevices()
                izShutdown()
            Catch ex As Exception
                Log("could not save devices")
            End Try
            bShutDown = True
        Catch ex As Exception
            Log("Error ending " & IFACE_NAME & " Plug-In")
        End Try

    End Sub
#End Region

#Region "Web Page Processing"

    Private Function SelectPage(ByVal pageName As String) As Object
        SelectPage = Nothing
        Select Case pageName
            Case ConfigPage.PageName
                SelectPage = ConfigPage
            Case StatusPage.PageName
                SelectPage = StatusPage
            Case Else
                SelectPage = ConfigPage
        End Select
    End Function

    Public Function postBackProc(page As String, data As String, user As String, userRights As Integer) As String
        WebPage = SelectPage(page)
        Return WebPage.postBackProc(page, data, user, userRights)
    End Function

    Public Function GetPagePlugin(ByVal pageName As String, ByVal user As String, ByVal userRights As Integer, ByVal queryString As String) As String
        ' build and return the actual page
        WebPage = SelectPage(pageName)
        Return WebPage.GetPagePlugin(pageName, user, userRights, queryString)
    End Function

#End Region

End Class
