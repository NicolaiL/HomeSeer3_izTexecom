﻿Imports System.Text
Imports System.Web
Imports Scheduler
Imports HomeSeerAPI
Imports System.IO.Ports

Public Class web_config
    Inherits clsPageBuilder
    Dim TimerEnabled As Boolean

    Dim sSpeed As String = ""
    Dim sDataBits As String = ""
    Dim sStopBits As String = ""
    Dim sHandShake As String = ""
    Dim sDebugLevel As String = ""
    Dim sConsole As String = ""

    ' Crestron
    Dim sIPAddress_Crestron = ""
    Dim sTCPPort_Crestron = ""
    Dim sSerPort_Crestron = ""
    Dim sPollingFrequencyCrestron As String = ""
    Dim sCommandDelay_Crestron As String = ""

    ' Simple Protocol
    Dim sIPAddress_Simple = ""
    Dim sTCPPort_Simple = ""
    Dim sSerPort_Simple = ""
    Dim sPollingFrequencySimple As String = ""
    Dim sUDLPassword As String = ""
    Dim sCommandDelay_Simple As String = ""

    Dim sNumberOfZones As String = ""
    Dim sPanelModel As String = ""
    Dim sZoneActiveLabel As String = ""
    Dim sZoneHealthyLabel As String = ""

    Public Sub New(ByVal pagename As String)
        MyBase.New(pagename)
    End Sub

    Public Overrides Function postBackProc(page As String, data As String, user As String, userRights As Integer) As String

        Dim parts As Collections.Specialized.NameValueCollection
        parts = HttpUtility.ParseQueryString(data)
        Select Case parts("id")
            Case "oDebugLevel"
                _DebugLevel = parts("DebugLevel")
                DebugLevel = _DebugLevel
                PostMessage("")
            Case "oConsoleDebug"
                _ConsoleDebugLevel = parts("ConsoleDebug")
                ConsoleDebugLevel = _ConsoleDebugLevel
                PostMessage("")
            Case "oNumberOfZones"
                ' Number of Zones updated. Run through and create the zones if they are missing
                Dim NewZoneNumber As Integer = Val(parts("NumberOfZones"))
                _NumberOfZones = NewZoneNumber
                NumberOfZones = _NumberOfZones
                CheckZoneDevices()
                PostMessage("Number of Zones updated. Zone Devices created if these were missing")
            Case "oUseSimpleProtocol"
                PostMessage("Please restart plug-in for this change to take effect")
                If parts("UseSimpleProtocol").ToLower = "checked" Then
                    _UseSimpleProtocol = True
                Else
                    _UseSimpleProtocol = False
                End If
                UseSimpleProtocol = _UseSimpleProtocol
                Dim ReturnVal As String = UpdateDevices()
                If ReturnVal <> "" Then PostMessage("Error updating devices: " & ReturnVal)
                WriteLog(DebugLog, "Setting Updated. Please restart plug-in", 5)
            Case "oPollingFrequencyCrestron"
                _PollingFrequency_Crestron = Val(parts("PollingFrequencyCrestron"))
                PollingFrequency(IniSection_Crestron) = _PollingFrequency_Crestron
                Try
                    Timer_Crestron.Stop()
                    Timer_Crestron.Dispose()
                Catch ex As Exception
                End Try

                Try
                    If _PollingFrequency_Crestron > 0 Then
                        Timer_Crestron = New System.Timers.Timer(1000 * _PollingFrequency_Crestron)
                        Timer_Crestron.Enabled = True
                        Timer_Crestron.Start()
                        PostMessage("Polling Frequency Updated")
                    Else
                        PostMessage("Polling Frequency Updated. Polling stopped.")
                    End If
                Catch ex As Exception
                End Try
            Case "oCommandDelay_Crestron"
                _CommandDelay_Crestron = Val(parts("CommandDelay_Crestron"))
                CommandDelay(IniSection_Crestron) = _CommandDelay_Crestron
                PostMessage("Command Delay Updated")
            Case "oUseComPortCrestron"
                PostMessage("Please restart plug-in for this change to take effect")
                If parts("UseComPortCrestron").ToLower = "checked" Then
                    _UseComPort_Crestron = False
                    COMPort(IniSection_Crestron) = ""
                Else
                    _UseComPort_Crestron = True
                    TCPPort(IniSection_Crestron) = ""
                    IPAddress(IniSection_Crestron) = ""
                End If
                Me.divToUpdate.Add("IPSection_Crestron", BuildComIPSection_Crestron)
                UseComPort(IniSection_Crestron) = _UseComPort_Crestron
                WriteLog(DebugLog, "Setting UseComPortCrestron to " & _UseComPort_Crestron, 5)
            Case "oIPAddressCrestron"
                ' Number of Zones updated. Run through and create the zones if they are missing
                _IPAddress_Crestron = parts("IPAddressCrestron")
                IPAddress(IniSection_Crestron) = _IPAddress_Crestron
                CloseizTCPPort_Crestron()
                OpenizTCPPort_Crestron()
                If izTCPStatus_Crestron = eConnection.Open Then
                    PostMessage("IP Address updated. Port connected")
                Else
                    PostMessage("Can't connect to Texecom device")
                End If
            Case "oTCPPortCrestron"
                ' Number of Zones updated. Run through and create the zones if they are missing
                Dim NewPort As Integer = Val(parts("TCPPortCrestron"))
                If NewPort > 0 And NewPort <= 65535 Then
                    _TCPPort_Crestron = NewPort
                    TCPPort(IniSection_Crestron) = _TCPPort_Crestron
                    CloseizTCPPort_Crestron()
                    OpenizTCPPort_Crestron()
                    If izTCPStatus_Crestron = eConnection.Open Then
                        PostMessage("TCP Port updated. Port connected")
                    Else
                        PostMessage("Can't connectto Texecom device")
                    End If
                Else
                    PostMessage("Invalid Port number. Must be between 1 and 65536")
                End If
            Case "oSerPort_Crestron"
                _SerPort_Crestron = parts("SerPort_Crestron")
                COMPort(IniSection_Crestron) = _SerPort_Crestron
                _rs232_Crestron.disconnect()
                Dim ReturnVal As String = OpenCOM_Crestron()
                If ReturnVal <> "" Then
                    PostMessage(ReturnVal)
                Else
                    PostMessage("COM Port opened")
                End If
            Case "oPollingFrequencySimple"
                _PollingFrequency_Simple = Val(parts("PollingFrequencySimple"))
                PollingFrequency(IniSection_Simple) = _PollingFrequency_Simple
                Try
                    Timer_Simple.Stop()
                    Timer_Simple.Dispose()
                Catch ex As Exception
                End Try

                Try
                    If _PollingFrequency_Simple > 0 Then
                        Timer_Simple = New System.Timers.Timer(1000 * _PollingFrequency_Simple)
                        Timer_Simple.Enabled = True
                        Timer_Simple.Start()
                        PostMessage("Polling Frequency Updated")
                    Else
                        PostMessage("Polling Frequency Updated. Polling stopped.")
                    End If
                Catch ex As Exception
                End Try
            Case "oCommandDelay_Simple"
                _CommandDelay_Simple = Val(parts("CommandDelay_Simple"))
                CommandDelay(IniSection_Simple) = _CommandDelay_Simple
                PostMessage("Command Delay Updated")
            Case "oUseComPortSimple"
                PostMessage("Please restart plug-in for this change to take effect")
                If parts("UseComPortSimple").ToLower = "checked" Then
                    _UseComPort_Simple = False
                    COMPort(IniSection_Simple) = ""
                Else
                    _UseComPort_Simple = True
                    TCPPort(IniSection_Simple) = ""
                    IPAddress(IniSection_Simple) = ""
                End If
                Me.divToUpdate.Add("IPSection_Simple", BuildComIPSection_Simple)
                UseComPort(IniSection_Simple) = _UseComPort_Simple
                WriteLog(DebugLog, "Setting UseComPortSimple to " & _UseComPort_Simple, 5)
            Case "oIPAddressSimple"
                ' Number of Zones updated. Run through and create the zones if they are missing
                _IPAddress_Simple = parts("IPAddressSimple")
                IPAddress(IniSection_Simple) = _IPAddress_Simple
                CloseizTCPPort_Simple()
                OpenizTCPPort_Simple()
                If izTCPStatus_Simple = eConnection.Open Then
                    PostMessage("IP Address updated. Port connected")
                Else
                    PostMessage("Can't connect to Texecom device")
                End If
            Case "oTCPPortSimple"
                ' Number of Zones updated. Run through and create the zones if they are missing
                Dim NewPort As Integer = Val(parts("TCPPortSimple"))
                If NewPort > 0 And NewPort <= 65535 Then
                    _TCPPort_Simple = NewPort
                    TCPPort(IniSection_Simple) = _TCPPort_Simple
                    CloseizTCPPort_Simple()
                    OpenizTCPPort_Simple()
                    If izTCPStatus_Simple = eConnection.Open Then
                        PostMessage("TCP Port updated. Port connected")
                    Else
                        PostMessage("Can't connectto Texecom device")
                    End If
                Else
                    PostMessage("Invalid Port number. Must be between 1 and 65536")
                End If
            Case "oSerPort_Simple"
                _SerPort_Simple = parts("SerPort_Simple")
                COMPort(IniSection_Simple) = _SerPort_Simple
                _rs232_Simple.disconnect()
                Dim ReturnVal As String = OpenCOM_Simple()
                If ReturnVal <> "" Then
                    PostMessage(ReturnVal)
                Else
                    PostMessage("COM Port opened")
                End If
            Case "oUDLPassword"
                _UDLPassword = parts("UDLPassword")
                UDLPassword = _UDLPassword
                PostMessage("UDL password updated.")
            Case "oPanelModel"
                Dim Selection As String = parts("PanelModel")
                Dim i As Integer
                Dim Selected As Integer = -1
                For i = 0 To _PanelTypes.Length - 1
                    If Selection = _PanelTypes(i) Then Selected = i
                Next
                _PanelModel = Selected
                PanelModel = _PanelModel
                PostMessage("Panel Model updated.")
            Case "oZoneActiveLabel"
                ZoneActiveLabel = parts("ZoneActiveLabel")
                UpdateDevices(_ZoneType)
                PostMessage("Label updated")
            Case "oZoneHealthyLabel"
                ZoneHealthyLabel = parts("ZoneHealthyLabel")
                UpdateDevices(_ZoneType)
                PostMessage("Label updated")
            Case "oSubmitButtonUpdate"
                UpdateDevices()
        End Select

        Return MyBase.postBackProc(page, data, user, userRights)
    End Function

    Public Function GetPagePlugin(ByVal pageName As String, ByVal user As String, ByVal userRights As Integer, ByVal queryString As String) As String
        Dim stb As New StringBuilder
        Dim instancetext As String = ""

        Try
            Me.reset()

            CurrentPage = Me

            ' handle any queries like mode=something
            Dim parts As Collections.Specialized.NameValueCollection = Nothing
            If (queryString <> "") Then
                parts = HttpUtility.ParseQueryString(queryString)
            End If
            If Instance <> "" Then instancetext = " - " & Instance
            'stb.Append(hs.GetPageHeader(pageName, IFACE_NAME & instancetext & " Config", "", "", True, False))

            Me.AddHeader(hs.GetPageHeader(pageName, "Configuration", "", "", False, True))

            stb.Append("<table border='0' cellpadding='0' cellspacing='0' width='1000'>")
            stb.Append("<tr><td width='1000' align='center' style='color:#FF0000; font-size:14pt; height:25px;'><strong><div id='message'>&nbsp;</div></strong></td></tr>")
            stb.Append("</table>")

            ' a message area for error messages from jquery ajax postback (optional, only needed if using AJAX calls to get data)
            stb.Append(clsPageBuilder.DivStart("errormessage", "class='errormessage'") & clsPageBuilder.DivEnd)

            'Me.RefreshIntervalMilliSeconds = 3000
            'stb.Append(Me.AddAjaxHandlerPost("id=timer", pageName))

            Dim jqtabs As New clsJQuery.jqTabs("tab1id", pageName)
            Dim tab As New clsJQuery.Tab
            tab.tabTitle = "Setup"
            tab.tabContent = BuildSetupTab()
            jqtabs.tabs.Add(tab)

            tab = New clsJQuery.Tab
            tab.tabTitle = "Crestron Protocol"
            tab.tabContent = BuildCrestronTab()
            jqtabs.tabs.Add(tab)
            jqtabs.defaultTab = 0

            If _UseSimpleProtocol Then
                tab = New clsJQuery.Tab
                tab.tabTitle = "Simple Protocol"
                tab.tabContent = BuildSimpleTab()
                jqtabs.tabs.Add(tab)
                jqtabs.defaultTab = 0
            End If

            tab = New clsJQuery.Tab
            tab.tabTitle = "Debug"
            tab.tabContent = BuildDebugTab()
            jqtabs.tabs.Add(tab)
            jqtabs.defaultTab = 0

            stb.Append(jqtabs.Build)

            stb.Append(clsPageBuilder.DivEnd)

            ' add the body html to the page
            Me.AddBody(stb.ToString)

            Me.AddFooter(hs.GetPageFooter)
            Me.suppressDefaultFooter = True

            ' return the full page
            Return Me.BuildPage()
        Catch ex As Exception
            'WriteMon("Error", "Building page: " & ex.Message)
            Return "error - " & Err.Description
        End Try
    End Function

    Function BuildSetupTab() As String
        Dim stb As New StringBuilder
        sNumberOfZones = _NumberOfZones.ToString
        sZoneActiveLabel = ZoneActiveLabel
        sZoneHealthyLabel = ZoneHealthyLabel


        ' Polling Frequency table
        stb.Append("<table border='1' cellpadding='1' cellspacing='0'>")
        stb.Append("<tr>")
        stb.Append("<td class='tablecolumn' width='200'>Zone Options:</td>")
        stb.Append("<td class='tablecolumn' width='100'></td>")
        stb.Append("</tr>")

        stb.Append("<tr>")
        stb.Append("<td>Number of Zones</td>")
        stb.Append("<td>" & BuildTextBox("NumberOfZones", 50, sNumberOfZones) & "</td>")
        stb.Append("</tr>")

        stb.Append("<tr>")
        stb.Append("<td>Text Label for Active zone</td>")
        stb.Append("<td>" & BuildTextBox("ZoneActiveLabel", 50, sZoneActiveLabel) & "</td>")
        stb.Append("</tr>")

        stb.Append("<tr>")
        stb.Append("<td>Text Label for Healthy zone</td>")
        stb.Append("<td>" & BuildTextBox("ZoneHealthyLabel", 50, sZoneHealthyLabel) & "</td>")
        stb.Append("</tr>")

        stb.Append("<tr>")
        stb.Append("<td>Use Simple Protocol on Second Serial Port</td>")
        stb.Append("<td>" & BuildCheckBox("UseSimpleProtocol", "", _UseSimpleProtocol, False) & "</td>")
        stb.Append("</tr>")

        stb.Append("<tr>")
        stb.Append("<td>Update izTexecom Devices to Latest version</td>")
        stb.Append("<td>" & BuildButton("SubmitButtonUpdate", "Submit") & "</td>")
        stb.Append("</tr>")

        stb.Append("<br>")
        stb.Append("</table>")
        Return stb.ToString
    End Function

    Function BuildCrestronTab() As String
        Dim stb As New StringBuilder
        sPollingFrequencyCrestron = _PollingFrequency_Crestron
        sCommandDelay_Crestron = _CommandDelay_Crestron.ToString

        ' Polling Frequency table
        stb.Append("<table border='1' cellpadding='1' cellspacing='0'>")
        stb.Append("<tr>")
        stb.Append("<td class='tablecolumn' width='200'>Plug-in Options:</td>")
        stb.Append("<td class='tablecolumn' width='100'></td>")
        stb.Append("</tr>")

        stb.Append("<tr>")
        stb.Append("<td>Polling Frequency (Secs.)</td>")
        stb.Append("<td>" & BuildTextBox("PollFrequencyCrestron", 50, sPollingFrequencyCrestron) & "</td>")
        stb.Append("</tr>")

        stb.Append("<tr>")
        stb.Append("<td>Delay between commands (ms)</td>")
        stb.Append("<td>" & BuildTextBox("CommandDelay_Crestron", 50, sCommandDelay_Crestron) & "</td>")
        stb.Append("</tr>")

        stb.Append("<tr><td><br></td></tr>")

        stb.Append("<tr>")
        stb.Append("<td>Use TCP/IP Connection</td>")
        stb.Append("<td>" & BuildCheckBox("UseComPortCrestron", "", Not _UseComPort_Crestron, False) & "</td>")
        stb.Append("</tr>")
        stb.Append("</table>")

        stb.Append(clsPageBuilder.DivStart("IPSection_Crestron", ""))
        stb.Append(BuildComIPSection_Crestron)
        stb.Append(clsPageBuilder.DivEnd)

        stb.Append("<br>")

        Return stb.ToString
    End Function

    Function BuildComIPSection_Crestron() As String
        Dim stb As New StringBuilder
        sIPAddress_Crestron = _IPAddress_Crestron
        sTCPPort_Crestron = _TCPPort_Crestron.ToString
        sSerPort_Crestron = _SerPort_Crestron

        If Not _UseComPort_Crestron Then
            stb.Append("<table border='1' cellpadding='1' cellspacing='0'>")
            stb.Append("<tr>")
            stb.Append("<td class='tablecolumn' width='200'>TCP/IP Settings:</td>")
            stb.Append("<td class='tablecolumn' width='100'></td>")
            stb.Append("</tr>")

            stb.Append("<tr>")
            stb.Append("<td>IP Address</td>")
            stb.Append("<td>" & BuildTextBox("IPAddressCrestron", 50, sIPAddress_Crestron) & "</td>")
            stb.Append("</tr>")

            stb.Append("<tr>")
            stb.Append("<td>TCP/IP Port</td>")
            stb.Append("<td>" & BuildTextBox("TCPPortCrestron", 50, sTCPPort_Crestron) & "</td>")
            stb.Append("</tr>")
        Else
            Dim ports = SerialPort.GetPortNames
            ReDim Preserve ports(ports.Length)
            ports(ports.Length - 1) = "NONE"
            stb.Append("<table border='0' cellpadding='0' cellspacing='0'>")
            stb.Append("<tr>")
            stb.Append("<td class='tablecolumn' width='200'>COM Port Settings:</td>")
            stb.Append("<td class='tablecolumn' width='100'></td>")
            stb.Append("</tr>")

            stb.Append("<tr>")
            stb.Append("<td>Serial Port</td>")
            stb.Append("<td>" & BuildDropList("SerPort_Crestron", "COM Port", sSerPort_Crestron, ports, False) & "</td>")
            stb.Append("</tr>")
        End If

        stb.Append("</table>")

        Return stb.ToString
    End Function

    Function BuildSimpleTab() As String
        Dim stb As New StringBuilder
        sPollingFrequencySimple = _PollingFrequency_Simple
        sUDLPassword = _UDLPassword
        sCommandDelay_Simple = _CommandDelay_Simple.ToString


        ' Polling Frequency table
        stb.Append("<table border='1' cellpadding='1' cellspacing='0'>")
        stb.Append("<tr>")
        stb.Append("<td class='tablecolumn' width='200'>Plug-in Options:</td>")
        stb.Append("<td class='tablecolumn' width='100'></td>")
        stb.Append("</tr>")

        stb.Append("<tr>")
        stb.Append("<td>Panel Model</td>")
        stb.Append("<td>" & BuildDropList("PanelModel", "Select Your Panel", _PanelTypes(_PanelModel), _PanelTypes, False) & "</td>")
        stb.Append("</tr>")

        stb.Append("<tr>")
        stb.Append("<td>UDL Password</td>")
        stb.Append("<td>" & BuildTextBox("UDLPassword", 50, sUDLPassword) & "</td>")
        stb.Append("</tr>")

        stb.Append("<tr>")
        stb.Append("<td>Polling Frequency (Secs.)</td>")
        stb.Append("<td>" & BuildTextBox("PollFrequencySimple", 50, sPollingFrequencySimple) & "</td>")
        stb.Append("</tr>")

        stb.Append("<tr>")
        stb.Append("<td>Delay between commands (ms)</td>")
        stb.Append("<td>" & BuildTextBox("CommandDelay_Simple", 50, sCommandDelay_Simple) & "</td>")
        stb.Append("</tr>")

        stb.Append("<tr><td><br></td></tr>")

        stb.Append("<tr>")
        stb.Append("<td>Use TCP/IP Connection</td>")
        stb.Append("<td>" & BuildCheckBox("UseComPortSimple", "", Not _UseComPort_Simple, False) & "</td>")
        stb.Append("</tr>")
        stb.Append("</table>")

        stb.Append(clsPageBuilder.DivStart("IPSection_Simple", ""))
        stb.Append(BuildComIPSection_Simple)
        stb.Append(clsPageBuilder.DivEnd)

        stb.Append("<br>")

        Return stb.ToString
    End Function

    Function BuildComIPSection_Simple() As String
        Dim stb As New StringBuilder
        sIPAddress_Simple = _IPAddress_Simple
        sTCPPort_Simple = _TCPPort_Simple.ToString
        sSerPort_Simple = _SerPort_Simple

        If Not _UseComPort_Simple Then
            stb.Append("<table border='1' cellpadding='1' cellspacing='0'>")
            stb.Append("<tr>")
            stb.Append("<td class='tablecolumn' width='200'>TCP/IP Settings:</td>")
            stb.Append("<td class='tablecolumn' width='100'></td>")
            stb.Append("</tr>")

            stb.Append("<tr>")
            stb.Append("<td>IP Address</td>")
            stb.Append("<td>" & BuildTextBox("IPAddressSimple", 50, sIPAddress_Simple) & "</td>")
            stb.Append("</tr>")

            stb.Append("<tr>")
            stb.Append("<td>TCP/IP Port</td>")
            stb.Append("<td>" & BuildTextBox("TCPPortSimple", 50, sTCPPort_Simple) & "</td>")
            stb.Append("</tr>")
        Else
            Dim ports = SerialPort.GetPortNames
            ReDim Preserve ports(ports.Length)
            ports(ports.Length - 1) = "NONE"
            stb.Append("<table border='0' cellpadding='0' cellspacing='0'>")
            stb.Append("<tr>")
            stb.Append("<td class='tablecolumn' width='200'>COM Port Settings:</td>")
            stb.Append("<td class='tablecolumn' width='100'></td>")
            stb.Append("</tr>")

            stb.Append("<tr>")
            stb.Append("<td>Serial Port</td>")
            stb.Append("<td>" & BuildDropList("SerPort_Simple", "COM Port", sSerPort_Simple, ports, False) & "</td>")
            stb.Append("</tr>")
        End If

        stb.Append("</table>")

        Return stb.ToString
    End Function

    Function BuildDebugTab() As String
        Dim stb As New StringBuilder

        sDebugLevel = DebugLevel
        sConsole = ConsoleDebugLevel


        stb.Append("<table border='1' cellpadding='1' cellspacing='0'>")
        stb.Append("<tr>")
        stb.Append("<td class='tablecolumn' width='200'>Debug Options:</td>")
        stb.Append("<td class='tablecolumn' width='50'></td>")
        stb.Append("</tr>")

        stb.Append("<tr>")
        stb.Append("<td>Log File Debug Level:</td>")
        stb.Append("<td>" & BuildTextBox("DebugLevel", 50, sDebugLevel) & "</td>")
        stb.Append("</tr>")

        stb.Append("<tr>")
        stb.Append("<td>Console Debug Level:</td>")
        stb.Append("<td>" & BuildTextBox("ConsoleDebug", 50, sConsole) & "</td>")
        stb.Append("</tr>")
        stb.Append("</table>")

        Return stb.ToString
    End Function

    Public Function BuildTextBox(ByVal Name As String, ByVal Width As Integer, Optional ByVal Text As String = "", Optional ByVal Rebuilding As Boolean = False) As String
        Dim tb As New clsJQuery.jqTextBox(Name, "", Text, Me.PageName, 20, False)
        Dim TextBox As String = ""
        tb.id = "o" & Name
        If Width > 0 Then tb.width = Width

        TextBox = tb.Build

        If Rebuilding Then
            Me.divToUpdate.Add(Name & "_div", TextBox)
        Else
            TextBox = "<div id='" & Name & "_div'>" & tb.Build & "</div>"
        End If

        Return TextBox
    End Function

    Function BuildButton(ByVal Name As String, Optional ByVal ButtonText As String = "Submit", Optional ByVal Content As String = "", Optional ByVal Rebuilding As Boolean = False) As String
        Dim Button As String
        Dim b As New clsJQuery.jqButton(Name, "", Me.PageName, True)

        b.submitForm = False
        b.id = "o" & Name
        b.label = ButtonText

        Button = b.Build

        If Rebuilding Then
            Me.divToUpdate.Add(Name & "_div", Button)
        Else
            Button = "<div id='" & Name & "_div'>" & Button & "</div>"
        End If
        Return Button
    End Function

    Function BuildCheckBox(ByVal Name As String, Label As String, Checked As Boolean, Optional ByVal Rebuilding As Boolean = False) As String
        Dim CheckBox As String
        Dim cb As New clsJQuery.jqCheckBox(Name, Label, Me.PageName, True, False)
        cb.id = "o" & Name
        cb.checked = Checked
        cb.LabelOnLeft = True
        cb.sliderStyle = True

        CheckBox = cb.Build

        If Rebuilding Then
            Me.divToUpdate.Add(Name & "_div", CheckBox)
        Else
            CheckBox = "<div id='" & Name & "_div'>" & CheckBox & "</div>"
        End If
        Return CheckBox
    End Function

    Function BuildDropList(ByVal Name As String, Label As String, Selected As String, ListItems() As String, Rebuilding As Boolean) As String

        Dim DropList As String = ""
        Dim dl As New clsJQuery.jqDropList(Name, Me.PageName, True)
        Dim i As Integer = 0
        Dim ThisOneSelected As Boolean = False
        For i = 0 To ListItems.Length - 1
            ThisOneSelected = (ListItems(i) = Selected)
            dl.AddItem(ListItems(i), ListItems(i), ThisOneSelected)
        Next
        dl.submitForm = False
        dl.id = "o" & Name

        DropList = dl.Build

        If Rebuilding Then
            Me.divToUpdate.Add(Name & "_div", DropList)
        Else
            DropList = "<div id='" & Name & "_div'>" & DropList & "</div>"
        End If

        Return DropList
    End Function

    Sub PostMessage(ByVal sMessage As String)
        Me.divToUpdate.Add("message", sMessage)
        'Me.pageCommands.Add("starttimer", "")
        'TimerEnabled = True
    End Sub

End Class

