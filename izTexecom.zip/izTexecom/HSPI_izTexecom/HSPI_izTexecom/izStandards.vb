﻿Imports HomeSeerAPI
Imports Scheduler
Imports System.Threading
Imports System.Text

' Moduel with standard constants, variables and procedures used by indigozest Plug-ins
Module izStd
    ' Added by Nicolai
    Friend Const IniFileName As String = "izTexecom.ini"
    Friend Const IniSection As String = "SETTINGS" ' Generic ini section for "stuff"

    Friend _DebugLevel As Byte = 0 ' Debug level, default is 0. Value contained in .INI file, stored in the generic section
    Friend _ConsoleDebugLevel As Byte = 0 ' Debug level for sending debug messages to the console
    Friend Const DebugLog As String = "izTexecom DEBUG" ' String used to preceed all DEBUG log messages
    Friend Const ErrorLog As String = "izTexecom ERROR" ' String used to preceed all ERROR log messages
    Friend Const WarningLog As String = "izTexecom Warning" ' String used to preceed all Warning log messages

    Private EncryptionString As String = "WeNeedMuchBetterSecurity" ' Password used for encrypting passwords with hs.encrypt

#Region "Properties"
    Friend Property DebugLevel() As String
        Get
            Dim ReadStr As String = hs.GetINISetting(IniSection, "Debug", "NONE", IniFileName)
            If (ReadStr = "NONE") Then ' ini file settings not initialised
                hs.SaveINISetting(IniSection, "Debug", "0", IniFileName)
                _DebugLevel = 0
            Else
                _DebugLevel = Val(ReadStr)
            End If
            Return _DebugLevel
        End Get
        Set(ByVal value As String)
            _DebugLevel = value
            hs.SaveINISetting(IniSection, "Debug", _DebugLevel.ToString, IniFileName)
        End Set
    End Property
    Friend Property ConsoleDebugLevel() As String
        Get
            Dim ReadStr As String = hs.GetINISetting(IniSection, "Console Debug", "NONE", IniFileName)
            If ReadStr = "NONE" Then ' ini file settings not initialised
                hs.SaveINISetting(IniSection, "Console Debug", "0", IniFileName)
                _ConsoleDebugLevel = 0
            Else
                _ConsoleDebugLevel = Val(ReadStr)
            End If
            Return _ConsoleDebugLevel
        End Get
        Set(ByVal value As String)
            _ConsoleDebugLevel = value
            hs.SaveINISetting(IniSection, "Console Debug", _ConsoleDebugLevel.ToString, IniFileName)
        End Set
    End Property
#End Region
#Region "Init, Shutdown and Setup"
    '    Property DebugLevel(Level As Byte)
    '        Get
    '
    '        End Get
    '        Set(value)
    '
    '    End Set
    'End Property
    Friend Function IniPlugIn() As String
        Dim DebugTest As String = ""

        Try ' Init INI file and read various variables
            WriteLog(DebugLog, "In izStd.IniPlugIn", 5)

            _DebugLevel = DebugLevel
            _ConsoleDebugLevel = ConsoleDebugLevel

            Return ""
        Catch ex As Exception
            WriteLog(DebugLog, "Exception from IniPlugIn: " & ex.Message, 0)
            Return "Exception from IniPlugIn: " & ex.Message
        End Try

    End Function
    Friend Function AddDeviceProperties(ByVal Device As Scheduler.Classes.DeviceClass, ByVal DeviceType As String, Optional ByVal Idx As Integer = -1) As Scheduler.Classes.DeviceClass
        If Idx <> -1 Then
            Device.Name(hs) = IFACE_NAME & DeviceType & " " & Idx.ToString
        Else
            Device.Name(hs) = IFACE_NAME & DeviceType
        End If
        Device.Location(hs) = IFACE_NAME
        Device.Location2(hs) = IFACE_NAME
        Device.Device_Type_String(hs) = IFACE_NAME & DeviceType
        Return Device
    End Function
    Friend Function AddVSPairs(ByRef Ref As Integer, ByRef Ctrl As ePairStatusControl, ByRef Value As Integer,
                               ByRef Status As String, ByRef Row As Integer, ByRef Col As Integer,
                               Optional ByRef RenderType As Enums.CAPIControlType = Enums.CAPIControlType.Button,
                               Optional ByRef Width As Integer = -1, Optional ByRef ControlUse As ePairControlUse = ePairControlUse.Not_Specified) As String

        Dim MyVSP As New VSPair(Ctrl)

        MyVSP.PairType = VSVGPairType.SingleValue
        MyVSP.Render_Location.Row = Row
        MyVSP.Render_Location.Column = Col
        MyVSP.Value = Value
        MyVSP.Status = Status
        MyVSP.IncludeValues = False
        MyVSP.ControlUse = ControlUse

        If Width <> -1 Then MyVSP.Render_Location.ColumnSpan = Width

        'MyVSP.Render = Enums.CAPIControlType.Button
        MyVSP.Render = RenderType

        'hs.DeviceVSP_AddPair(Ref, MyVSP)
        If Not hs.DeviceVSP_AddPair(Ref, MyVSP) Then
            WriteLog(ErrorLog, "VSPair could not be added for device, ref: " & Ref.ToString, 0)
            Return "VSPair could not be added for device, ref: " & Ref.ToString
        End If

        Return ""
    End Function
#End Region
#Region "Text Manipulation Functions"
    Friend Function StrToHexString(ByVal ReceiveData As String, Optional ByRef HexOutput As Boolean = True) As String
        Dim i As Integer
        Dim a As String

        If HexOutput Then
            a = " (Hex): "
            For i = 0 To ReceiveData.Length - 1
                a += Hex(Asc(ReceiveData(i))) & " "
            Next
        Else
            a = " (ASCII): "
            For i = 0 To ReceiveData.Length - 1
                a += Asc(ReceiveData(i)) & " "
            Next
        End If

        StrToHexString = a & " Length: " & ReceiveData.Length

    End Function
    Friend Function StrToByteArray(ByVal text As String) As Byte()
        Dim encoding As New System.Text.UTF8Encoding()
        StrToByteArray = encoding.GetBytes(text)
    End Function
    Friend Function BytesToString(ByVal data() As Byte) As String
        BytesToString = ""
        Dim i As Integer
        For i = 0 To data.Length - 1
            BytesToString += Chr(data(i))
        Next
    End Function
#End Region
#Region "Encryption"
    Friend Function EncryptedString(ByRef InputString As String) As String
        Dim sCombination As String = ""
        sCombination = hs.EncryptString(InputString, EncryptionString)
        ' I now have my encrypted combination in sCombination.  I must remember
        '   to use HomeSeer's or Microsoft's script encrypters on this script
        '   since my password string is plainly visible above! 
        ' I want to store the combination in a text file, so let's Base64 encode it.
        Dim bteArray() As Byte
        bteArray = Encoding.ASCII.GetBytes(sCombination)
        Dim sOutput As String = ""
        sOutput = Convert.ToBase64String(bteArray, Base64FormattingOptions.None)
        Return sOutput
    End Function
    Friend Function DecryptedString(ByRef InputString As String) As String
        ' Now decode the string back into an array of bytes.
        Dim bteArray() As Byte
        bteArray = Convert.FromBase64String(InputString)
        Dim sCombEntered As String = ""
        sCombEntered = Encoding.ASCII.GetString(bteArray)
        ' Now we have the encrypted combination, so let's decrypt it. (We'll re-use sCombination)
        Dim OutputString As String = hs.DecryptString(sCombEntered, EncryptionString)
        Return OutputString
    End Function
#End Region
#Region "Bit Manipulation"
    Private Function GetBit(b As Byte, bitNumber As Integer) As Boolean
        Return (b And (1 << bitNumber)) <> 0
    End Function
    Private Function SetBit(b As Byte, bitnumber As Integer, OnOff As Boolean) As Byte
        Dim mask As Byte
        If OnOff Then ' Set bit ON
            mask = 1 << bitnumber
            SetBit = b Or mask
        Else ' Set to OFF
            mask = 255 - (1 << bitnumber)
            SetBit = b And mask
        End If

    End Function
#End Region
#Region "Debug Items"
    Friend Sub WriteLog(ByRef LogType As String, ByRef LogString As String, ByRef MsgLevel As Integer, Optional ByRef IncludeProcName As Boolean = False)
        If LogType = ErrorLog Or IncludeProcName Then
            Dim stackframe As New Diagnostics.StackFrame(1)
            Dim PriorProc As String = stackframe.GetMethod().Name
            LogString = PriorProc & ": " & LogString
        End If
        If MsgLevel <= 1 Then hs.WriteLog(LogType, LogString)

        If _DebugLevel >= MsgLevel Then hs.WriteLog(LogType, LogString)
        'If IO.Directory.Exists(gEXEPath & "\Debug Logs") Then
        '    IO.File.AppendAllText(gEXEPath & "\Debug Logs\" & IFACE_NAME & ".log", Now.ToString & " ~ " & LogString & vbCrLf)
        'ElseIf IO.Directory.Exists(gEXEPath & "\Logs") Then
        '    IO.File.AppendAllText(gEXEPath & "\Logs\" & IFACE_NAME & ".log", Now.ToString & " ~ " & LogString & vbCrLf)
        'Else
        '    IO.File.AppendAllText(gEXEPath & "\" & IFACE_NAME & ".log", Now.ToString & " ~ " & LogString & vbCrLf)
        'End If

        'End If

        If _ConsoleDebugLevel >= MsgLevel Then Console.WriteLine(LogString)
    End Sub
#End Region

End Module
