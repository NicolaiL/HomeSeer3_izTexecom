﻿Imports HomeSeerAPI
Imports Scheduler
Imports System.Threading

' Copyright (C) 2015 indigozest Ltd., www.indigozest.co.uk
' Texecom Alarm system integration plug-in
' All Rights Reserved
'
' Revision History
' v3.0.1.11 - Quick fix to support new Arming protocol standard
' v3.0.1.10 - Working on linux support
' v3.0.1.9 - Fixing error with panel read time
' v3.0.1.8 - minor alterations based on feedback received
' v3.0.1.7 - beta for X-10 Controlled Outputs and reading the log. Added link to help file
' v3.0.1.6 - Internal WIP
' v3.0.1.5 - beta wit Voltages and Panel Time support
' v3.0.1.4 - WIP
' v3.0.1.3 - for Simple support and better handling of updating devices, including:
'           Info comannd updates Root device string with Panel Info
'           Devices are now updated when Simple is switched on/off and a button exists on setup page to force the udpate
' v3.0.1.2 - beta version with support for Arm command set
' v3.0.1.1 - WIP for Simple protocol / second serial card
' v3.0.1.0 - First PROD release
' v3.0.0.5 - Initial Release beta version
' v3.0.0.4 - WIP for key presses
' v3.0.0.2 - beta - Now with License required and SendKeyPress
' v3.0.0.1 - Initial closed beta version
' V0.0.0.1 - Initial WIP
'
' TO DO:
' ------
' Ensure port debug statements adequately refers to Crestron or Simple
' Fix debug entry text boxes on config screen
' Turn PC Output On/Off
' Create "Device Version" in ini file to equal current file version. Read at setup and written at shut down. Used for knowing if devices should be updated.
' Register a Help link to the PDF file: http://home.indigozest.net/FTP/HomeSeer3/izTexecomy/izTexecom_manual.pdf
' Need logic to stop error message in log during initial startup for bad packets
' Check why Menu 1,2,3 and 4, and also Area does not work with Keypad - Speak to Texecom support
' Change to poll partitition status through Simple and switch off Crestron when Simple is present
' Need ability to write to separate log file for easier swapping of debug stuff

Module izTexecom
#Region "Variables"
    Friend _CurrentRoot As Integer = 0 ' Current DIM ROOT device ref used

    Friend _NumberOfZones As Integer = 0

    ' Set to True when ASTATUS is issued to the panel as this commands does not respond uniformly across panels so helps to determine if incoming response is valid or noise
    Friend AstatusInProgress As Boolean = False

    ' For the first COM port with the Crestron Protocol
    Friend WithEvents _rs232_Crestron As New RS232
    Private isConnected_Crestron As Boolean
    Private RXcount_Crestron, TXcount_Crestron As Integer
    Private comparams_Crestron() As String = RS232.DefaultParams
    Private buffer_Crestron() As Byte
    Friend _SerPort_Crestron As String = "" ' Serial port
    Friend _SerPortValue_Crestron As Integer = 0
    Friend _SerSpeed_Crestron As Integer = 19200 ' Default COM speed
    Friend _SerDataBits_Crestron As Byte = 8
    Friend _SerStopBits_Crestron As Byte = 1

    Private izComLeftOverData_Crestron As String = "" ' Where a packet is received that contains fragments of the following packet these left over data are store here
    Private LastPacket_Crestron As String = "" ' Used to see if we get the same data twice so we don't have to update more than once

    Friend Const IniSection_Crestron As String = "CRESTRONCOM" ' Ini section for serial port setup
    Friend _CommandDelay_Crestron As Integer = 0

    Friend _IPAddress_Crestron As String = "192.168.9.19"
    Friend _TCPPort_Crestron As Integer = 20108
    Friend _UseComPort_Crestron As Boolean = True
    Friend izTCPStatus_Crestron As eConnection = eConnection.Closed
    Public izTCPClient_Crestron As ConnectionInfo

    Private Const _CmdStart_Crestron As String = Chr(34)
    Private Const _CmdEnd_Crestron As String = Chr(10)

    Friend WithEvents Timer_Crestron As Timers.Timer
    Friend _PollingFrequency_Crestron As Integer = 60 * 5 ' Timer in seconds for a full poll

    ' For the first COM port with the Simple Protocol
    Friend _UseSimpleProtocol As Boolean = False

    Friend WithEvents _rs232_Simple As New RS232
    Private isConnected_Simple As Boolean
    Private RXcount_Simple, TXcount_Simple As Integer
    Private comparams_Simple() As String = RS232.DefaultParams
    Private buffer_Simple() As Byte
    Friend _SerPort_Simple As String = "" ' Serial port
    Friend _SerPortValue_Simple As Integer = 0
    Friend _SerSpeed_Simple As Integer = 19200 ' Default COM speed
    Friend _SerDataBits_Simple As Byte = 8
    Friend _SerStopBits_Simple As Byte = 2

    Private izComLeftOverData_Simple As String = "" ' Where a packet is received that contains fragments of the following packet these left over data are store here
    Private LastPacket_Simple As String = "" ' Used to see if we get the same data twice so we don't have to update more than once

    Friend Const IniSection_Simple As String = "SIMPLECOM" ' Ini section for serial port setup
    Friend _CommandDelay_Simple As Integer = 0

    Friend _IPAddress_Simple As String = "192.168.9.19"
    Friend _TCPPort_Simple As Integer = 20108
    Friend _UseComPort_Simple As Boolean = True
    Friend izTCPStatus_Simple As eConnection = eConnection.Closed
    Public izTCPClient_Simple As ConnectionInfo

    Friend _UDLPassword As String = ""
    Friend TimeofLastSimpleCommand As Date = Now()
    Friend LastSimpleComand As eSimpleCommmands
    Friend LastSimpleRef As Integer = 0 ' Used to contain the dvRef of the last Device that was called for an update by a Simple command
    Private Const _CmdStart_Simple As String = Chr(92)
    Private Const _CmdEnd_Simple As String = Chr(47)

    Friend WithEvents Timer_Simple As Timers.Timer
    Friend _PollingFrequency_Simple As Integer = 60 * 5 ' Timer in seconds for a full poll

    ' Timer for Garbage Collection etc.
    Friend WithEvents GeneralTimer As Timers.Timer
    Private GeneralTimerInterval As Integer = 600

    ' Panel Model - used when Simple protocol is in use as some commands are different
    Friend _PanelModel As Integer = 0 ' 0 = Not selected

    ' Variables used for reading/storing the log from the panel
    Friend _PanelLogMessages(4) As String
    Friend _LogIndex As Integer = -1 ' 
    Friend _LogReadFromTimer As Boolean = True ' Do not udpate display when read from here
    Friend _LogDisplayIndex As Integer = 0 ' Which entry is currently displayed
#End Region
#Region "Enumerations"
    Friend Enum eConnection
        Closed = 0
        Open = 1
    End Enum
    Friend Enum eRootStatus
        ArmStatus = -1001
    End Enum
    Friend Enum eZoneStatus
        Healthy = 0
        Active = 1
        Tamper = 2
    End Enum
    Friend Enum eAreaStatus
        Armed = 1
        Disarmed = 0
        Arm = -101
        Disarm = -102
        PartArm = -103
        Reset = -104
        PartArmed = -105
    End Enum
    Friend Enum eLCD
        ViewStatus = -1001
    End Enum
    Friend Enum eSimpleDevice
        Unknown = -1
        LoggedIn = 1
        [Error] = 2
    End Enum
    Friend Enum eSimpleCommmands ' Different commands that are carried out via the Simnple protocol
        Login = 1
        Arm = 2
        Disarm = 3
        PartArm = 4
        Reset = 5
        PanelInfo = 6
        ReadPanelTime = 7
        SetPanelTime = 8
        ReadVoltages = 9
        X10On = 10
        X10Off = 11
        ReadLog = 12
    End Enum
    Friend Enum ePanelTimeDevice
        Unknown = -1
        ReadTime = -1001
        SetTime = -1002
    End Enum
    Friend Enum eZoneInfo
        Unknown = -1
    End Enum
    Friend Enum eVoltages
        Unknown = -1
        Read = -1001
    End Enum
    Friend Enum eX10
        Unknown = -1
        [On] = 100
        Off = 0
    End Enum
    Friend Enum ePanelLog
        Unknown = -1
        Up = -1001
        Down = -1002
        Read = -1003
    End Enum
#End Region


#Region "Device Constants"
    Friend _RootAddress As String = "-ROOT"
    Friend _RootType As String = " Root"

    Friend _ZoneAddress As String = "-ZONE"
    Friend _ZoneType As String = " Zone"

    Friend _AreaAddress As String = "-A"
    Friend _AreaType As String = " Area"

    Friend _LCDAddress As String = "-LCD"
    Friend _LCDType As String = " LCD"

    Friend _SimpleAddress As String = "-SIMPLE"
    Friend _SimpleType As String = " Simple"

    Friend _PanelTimeAddress As String = "-PANELTIME"
    Friend _PanelTimeType As String = " Panel Time"

    Friend _SystemVoltageAddress As String = "-SYSVOLTAGE"
    Friend _SystemVoltageType As String = " System Voltage"

    Friend _BatteryVoltageAddress As String = "-BATVOLTAGE"
    Friend _BatteryVoltageType As String = " Battery Voltage"

    Friend _SystemCurrentAddress As String = "-SYSCURRENT"
    Friend _SystemCurrentType As String = " System Current"

    Friend _BatteryCurrentAddress As String = "-BATCURRENT"
    Friend _BatteryCurrentType As String = " Battery Charging Current"

    Friend _OutputX10Address As String = "-X10"
    Friend _OutputX10Type As String = " X10 Output"

    Friend _PanelLogAddress As String = "-LOG"
    Friend _PanelLogType As String = " Panel Log"

    Friend _SendKeyPressCmd As Char() = {"Command", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "Y", "N", "O", "C", "P", "A", "R", "U", "D", "M", "F", "+"}
    Friend _SendKeyPressLabel As String() = {"Command", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "Yes", "No", "Omit", "Chime", "Part", "Area", "Reset", "Up Arrow", "Down Arrow", "Menu", "Keypad Fire", "Keypad Medical"}

    Friend _PanelTypes As String() = {"Not Set", "Elite 12/24/48/88/168/640", "Premier 48/88/168", "Premier 640 Simple protocol"}
#End Region

#Region "Ini File Properties"
    Friend Property PollingFrequency(ByVal Section As String) As Integer
        Get
            Dim ReadStr As String = hs.GetINISetting(Section, "Polling Frequency", "NONE", IniFileName)
            If ReadStr = "NONE" Then
                hs.SaveINISetting(Section, "Polling Frequency", "60", IniFileName)
                Return 60
            Else
                Return Val(ReadStr)
            End If
        End Get
        Set(value As Integer)
            hs.SaveINISetting(Section, "Polling Frequency", value.ToString, IniFileName)
        End Set
    End Property
    Public Property UseComPort(ByVal Section As String) As Boolean
        Get
            Dim ReadStr As String = hs.GetINISetting(Section, "Use COM Port", "NONE", IniFileName)
            If ReadStr = "NONE" Then
                hs.SaveINISetting(Section, "Use COM Port", "TRUE", IniFileName)
                Return True
            Else
                Return CBool(ReadStr)
            End If
        End Get
        Set(value As Boolean)
            hs.SaveINISetting(Section, "Use COM Port", value, IniFileName)
        End Set
    End Property
    Public Property IPAddress(ByVal Section As String) As String
        Get
            Dim ReadStr As String = hs.GetINISetting(Section, "IPAddress", "NONE", IniFileName)
            If ReadStr = "NONE" Then
                hs.SaveINISetting(Section, "IPAddress", "192.168.9.19", IniFileName)
                Return "192.168.9.19"
            Else
                Return ReadStr
            End If
        End Get
        Set(value As String)
            hs.SaveINISetting(Section, "IPAddress", value, IniFileName)
        End Set
    End Property
    Public Property TCPPort(ByVal Section As String) As String
        Get
            Dim ReadStr As String = hs.GetINISetting(Section, "TCP Port", "NONE", IniFileName)
            If ReadStr = "NONE" Or Val(ReadStr) = 0 Then
                hs.SaveINISetting(Section, "TCP Port", "20108", IniFileName)
                Return "20108"
            Else
                Return ReadStr
            End If
        End Get
        Set(value As String)
            hs.SaveINISetting(Section, "TCP Port", value, IniFileName)
        End Set
    End Property
    Public Property COMPort(ByVal Section As String) As String
        Get
            Dim ReadStr As String = hs.GetINISetting(Section, "COM Port", "NONE", IniFileName)
            Return ReadStr
        End Get
        Set(value As String)
            hs.SaveINISetting(Section, "COM Port", value, IniFileName)
        End Set
    End Property
    Friend Property CommandDelay(ByVal Section As String) As Integer
        Get
            Dim stackframe As New Diagnostics.StackFrame(0)
            Dim IniEntryName As String = stackframe.GetMethod().Name
            IniEntryName = Right(IniEntryName, IniEntryName.Length - 4)
            Dim ReadStr As String = hs.GetINISetting(Section, IniEntryName, "NONE", IniFileName)
            If ReadStr = "NONE" Then
                hs.SaveINISetting(Section, IniEntryName, "500", IniFileName)
                Return 500
            Else
                Return Val(ReadStr)
            End If
        End Get
        Set(value As Integer)
            Dim stackframe As New Diagnostics.StackFrame(0)
            Dim IniEntryName As String = stackframe.GetMethod().Name
            IniEntryName = Right(IniEntryName, IniEntryName.Length - 4)
            hs.SaveINISetting(Section, IniEntryName, value.ToString, IniFileName)
        End Set
    End Property
    Friend Property NumberOfZones() As Integer
        Get
            Dim stackframe As New Diagnostics.StackFrame(0)
            Dim IniEntryName As String = stackframe.GetMethod().Name
            IniEntryName = Right(IniEntryName, IniEntryName.Length - 4)
            Dim ReadStr As String = hs.GetINISetting(IniSection, IniEntryName, "NONE", IniFileName)
            If ReadStr = "NONE" Then
                hs.SaveINISetting(IniSection, IniEntryName, "1", IniFileName)
                Return 1
            Else
                Return Val(ReadStr)
            End If
        End Get
        Set(value As Integer)
            Dim stackframe As New Diagnostics.StackFrame(0)
            Dim IniEntryName As String = stackframe.GetMethod().Name
            IniEntryName = Right(IniEntryName, IniEntryName.Length - 4)
            hs.SaveINISetting(IniSection, IniEntryName, value.ToString, IniFileName)
        End Set
    End Property
    Friend Property PanelModel() As Integer
        Get
            Dim stackframe As New Diagnostics.StackFrame(0)
            Dim IniEntryName As String = stackframe.GetMethod().Name
            IniEntryName = Right(IniEntryName, IniEntryName.Length - 4)
            Dim ReadStr As String = hs.GetINISetting(IniSection, IniEntryName, "NONE", IniFileName)
            If ReadStr = "NONE" Then
                hs.SaveINISetting(IniSection, IniEntryName, "0", IniFileName)
                Return 0
            Else
                Return Val(ReadStr)
            End If
        End Get
        Set(value As Integer)
            Dim stackframe As New Diagnostics.StackFrame(0)
            Dim IniEntryName As String = stackframe.GetMethod().Name
            IniEntryName = Right(IniEntryName, IniEntryName.Length - 4)
            hs.SaveINISetting(IniSection, IniEntryName, value.ToString, IniFileName)
        End Set
    End Property
    Friend Property UseSimpleProtocol() As Boolean
        Get
            Dim stackframe As New Diagnostics.StackFrame(0)
            Dim IniEntryName As String = stackframe.GetMethod().Name
            IniEntryName = Right(IniEntryName, IniEntryName.Length - 4)
            Dim ReadStr As String = hs.GetINISetting(IniSection, IniEntryName, "NONE", IniFileName)
            If ReadStr = "NONE" Then
                hs.SaveINISetting(IniSection, IniEntryName, "FALSE", IniFileName)
                Return False
            Else
                Return CBool(ReadStr)
            End If
        End Get
        Set(value As Boolean)
            Dim stackframe As New Diagnostics.StackFrame(0)
            Dim IniEntryName As String = stackframe.GetMethod().Name
            IniEntryName = Right(IniEntryName, IniEntryName.Length - 4)
            hs.SaveINISetting(IniSection, IniEntryName, value, IniFileName)
        End Set
    End Property
    Friend ReadOnly Property CurrentVersion() As String
        Get
            Dim myFileVersionInfo As FileVersionInfo = FileVersionInfo.GetVersionInfo("HSPI_izTexecom.exe")
            Return myFileVersionInfo.FileVersion
        End Get
    End Property
    Friend Property LastVersion() As String
        Get
            Dim stackframe As New Diagnostics.StackFrame(0)
            Dim IniEntryName As String = stackframe.GetMethod().Name
            IniEntryName = Right(IniEntryName, IniEntryName.Length - 4)
            Dim ReadStr As String = hs.GetINISetting(IniSection, IniEntryName, "NONE", IniFileName)
            If ReadStr = "NONE" Then
                hs.SaveINISetting(IniSection, IniEntryName, "3.0.0.1", IniFileName)
                Return "3.0.0.1"
            Else
                Return ReadStr
            End If
        End Get
        Set(value As String)
            Dim stackframe As New Diagnostics.StackFrame(0)
            Dim IniEntryName As String = stackframe.GetMethod().Name
            IniEntryName = Right(IniEntryName, IniEntryName.Length - 4)
            hs.SaveINISetting(IniSection, IniEntryName, value.ToString, IniFileName)
        End Set
    End Property
    Public Property UDLPassword() As String
        Get
            Dim ReadStr As String = hs.GetINISetting(IniSection_Simple, "UDL Password", "NONE", IniFileName)
            If ReadStr = "NONE" Then
                hs.SaveINISetting(IniSection_Simple, "UDL Password", EncryptedString("1234"), IniFileName)
                Return "1234"
            Else
                Return DecryptedString(ReadStr)
            End If
        End Get
        Set(value As String)
            hs.SaveINISetting(IniSection_Simple, "UDL Password", EncryptedString(value), IniFileName)
        End Set
    End Property
    Friend Property ZoneHealthyLabel() As String
        Get
            Dim stackframe As New Diagnostics.StackFrame(0)
            Dim IniEntryName As String = stackframe.GetMethod().Name
            IniEntryName = Right(IniEntryName, IniEntryName.Length - 4)
            Dim ReadStr As String = hs.GetINISetting(IniSection, IniEntryName, "Healthy", IniFileName)
            If ReadStr = "Healthy" Then
                hs.SaveINISetting(IniSection, IniEntryName, "Healthy", IniFileName)
                Return "Healthy"
            Else
                Return ReadStr
            End If
        End Get
        Set(value As String)
            Dim stackframe As New Diagnostics.StackFrame(0)
            Dim IniEntryName As String = stackframe.GetMethod().Name
            IniEntryName = Right(IniEntryName, IniEntryName.Length - 4)
            hs.SaveINISetting(IniSection, IniEntryName, value.ToString, IniFileName)
        End Set
    End Property
    Friend Property ZoneActiveLabel() As String
        Get
            Dim stackframe As New Diagnostics.StackFrame(0)
            Dim IniEntryName As String = stackframe.GetMethod().Name
            IniEntryName = Right(IniEntryName, IniEntryName.Length - 4)
            Dim ReadStr As String = hs.GetINISetting(IniSection, IniEntryName, "Active", IniFileName)
            If ReadStr = "Active" Then
                hs.SaveINISetting(IniSection, IniEntryName, "Active", IniFileName)
                Return "Active"
            Else
                Return ReadStr
            End If
        End Get
        Set(value As String)
            Dim stackframe As New Diagnostics.StackFrame(0)
            Dim IniEntryName As String = stackframe.GetMethod().Name
            IniEntryName = Right(IniEntryName, IniEntryName.Length - 4)
            hs.SaveINISetting(IniSection, IniEntryName, value.ToString, IniFileName)
        End Set
    End Property
#End Region

#Region "Device Address Properties"
    Friend ReadOnly Property AreaAddress(Idx) As String
        Get
            Return IFACE_NAME & _AreaAddress & Format(Idx, "000").ToString
        End Get
    End Property
    Friend ReadOnly Property ZoneAddress(Idx) As String
        Get
            Return IFACE_NAME & _ZoneAddress & Format(Idx, "000").ToString
        End Get
    End Property
    Friend ReadOnly Property LCDAddress() As String
        Get
            Return IFACE_NAME & _LCDAddress
        End Get
    End Property
    Friend ReadOnly Property SimpleAddress() As String
        Get
            Return IFACE_NAME & _SimpleAddress
        End Get
    End Property
    Friend ReadOnly Property RootAddress() As String
        Get
            Return IFACE_NAME & _RootAddress
        End Get
    End Property
    Friend ReadOnly Property PanelTimeAddress() As String
        Get
            Return IFACE_NAME & _PanelTimeAddress
        End Get
    End Property
    Friend ReadOnly Property SystemVoltageAddress() As String
        Get
            Return IFACE_NAME & _SystemVoltageAddress
        End Get
    End Property
    Friend ReadOnly Property BatteryVoltageAddress() As String
        Get
            Return IFACE_NAME & _BatteryVoltageAddress
        End Get
    End Property
    Friend ReadOnly Property SystemCurrentAddress() As String
        Get
            Return IFACE_NAME & _SystemCurrentAddress
        End Get
    End Property
    Friend ReadOnly Property BatteryCurrentAddress() As String
        Get
            Return IFACE_NAME & _BatteryCurrentAddress
        End Get
    End Property
    Friend ReadOnly Property X10OutputAddress(Idx) As String
        Get
            Return IFACE_NAME & _OutputX10Address & Format(Idx, "0").ToString
        End Get
    End Property
    Friend ReadOnly Property PanelLogAddress() As String
        Get
            Return IFACE_NAME & _PanelLogAddress
        End Get
    End Property
#End Region

#Region "Timer Event"
    Private Sub TimerCrestron_Elapsed(ByVal sender As Object, ByVal e As System.Timers.ElapsedEventArgs) Handles Timer_Crestron.Elapsed
        Dim Result As String = ""
        WriteLog(DebugLog, "Running Crestron timer event ...", 5)
        Try
            If _UseComPort_Crestron Then
                ' Check COM port is OK
                If Not isConnected_Crestron Then
                    ' COM port has lost communication. Try to re-open
                    WriteLog(ErrorLog, "COM port Is unexpectedly closed. Attempting to re-open ...", 0)
                    OpenCOM_Crestron()
                End If
            Else
                If Not izTCPClient_Crestron.Client.Connected Then
                    WriteLog(ErrorLog, "TCP port dicconnected. Attempting to reconnect ...", 0)
                    CloseizTCPPort_Crestron()
                    OpenizTCPPort_Crestron()
                End If
            End If
        Catch ex As Exception
            WriteLog(ErrorLog, "Error in Crestron Timer function. Error message:  " & ex.Message, 0)
            Exit Sub
        End Try
        SendTexecomCommand_Crestron("LSTATUS")
        Thread.Sleep(500)
        If Not _UseComPort_Simple Then
            AstatusInProgress = True
            SendTexecomCommand_Crestron("ASTATUS")
        End If
    End Sub
    Private Sub TimerSimple_Elapsed(ByVal sender As Object, ByVal e As System.Timers.ElapsedEventArgs) Handles Timer_Simple.Elapsed
        Dim Result As String = ""
        WriteLog(DebugLog, "Running Simple timer event ...", 5)
        Try
            If _UseComPort_Simple Then
                ' Check COM port is OK
                If Not isConnected_Simple Then
                    ' COM port has lost communication. Try to re-open
                    WriteLog(ErrorLog, "COM port Is unexpectedly closed. Attempting to re-open ...", 0)
                    OpenCOM_Simple()
                End If
            Else
                If Not izTCPClient_Simple.Client.Connected Then
                    WriteLog(ErrorLog, "TCP port dicconnected. Attempting to reconnect ...", 0)
                    CloseizTCPPort_Simple()
                    OpenizTCPPort_Simple()
                End If
            End If
        Catch ex As Exception
            WriteLog(ErrorLog, "Error in Simple Timer function. Error message:  " & ex.Message, 0)
            Exit Sub
        End Try

        ' Send SIMPLE polled queries here
        ' Such as update areas
        Simple_ReadPanelTime()
        Simple_ReadVoltages()
        _LogReadFromTimer = True
        Simple_PanelLogRead()

        ' XXXXXXXXXXXXXXXXXXXXXXXXXXXXX
        ' XXXXXXXXXXXXXXXXXXXXXXXXXXXXX
        ' XXXXXXXXXXXXXXXXXXXXXXXXXXXXX
        ' XXXXXXXXXXXXXXXXXXXXXXXXXXXXX
    End Sub
    Friend Sub GeneralTimer_Elapsed(ByVal sender As Object, ByVal e As System.Timers.ElapsedEventArgs) Handles GeneralTimer.Elapsed
        ' Usded for general timer based tasks. Runs once per minute
        WriteLog(DebugLog, "Running General Timer", 5)
        GC.Collect()  'Collect garbage from other threads etc.
        WriteLog(DebugLog, "Garbage Collection Complete", 5)
    End Sub
#End Region

#Region "Init And Shutdown"
    Friend Function izInit(ByRef port As String) As String
        Dim ReturnVal As String = ""
        '_SerPort_Crestron = port

        Try
            WriteLog(DebugLog, "In izInit...", 5)
            ' First initialise settings from izStandards
            izStd.IniPlugIn()


            WriteLog(IFACE_NAME, "Plug-In Version " & CurrentVersion, 0)

            ' Read INI file settings
            _PollingFrequency_Crestron = PollingFrequency(IniSection_Crestron)

            ' Now read appropriate INI file and get IP address and port settings 
            _UseComPort_Crestron = UseComPort(IniSection_Crestron)
            _CommandDelay_Crestron = CommandDelay(IniSection_Crestron)
            If Not _UseComPort_Crestron Then
                _IPAddress_Crestron = IPAddress(IniSection_Crestron)
                _TCPPort_Crestron = TCPPort(IniSection_Crestron)
            Else
                _SerPort_Crestron = COMPort(IniSection_Crestron)
            End If

            ' Check if we are using a second serial card
            _UseSimpleProtocol = UseSimpleProtocol
            If _UseSimpleProtocol Then
                _PollingFrequency_Simple = PollingFrequency(IniSection_Simple)
                _UseComPort_Simple = UseComPort(IniSection_Simple)
                _UDLPassword = UDLPassword
                _CommandDelay_Simple = CommandDelay(IniSection_Simple)
                _PanelModel = PanelModel
                If Not _UseComPort_Simple Then
                    _IPAddress_Simple = IPAddress(IniSection_Simple)
                    _TCPPort_Simple = TCPPort(IniSection_Simple)
                Else
                    _SerPort_Simple = COMPort(IniSection_Simple)
                End If
                ' Clear the panel log message array
                For i As Integer = 0 To _PanelLogMessages.Length - 1
                    _PanelLogMessages(i) = ""
                Next
            End If

            ' Now check if devices exists, by looking up the first one, or alternatively create
            _CurrentRoot = hs.DeviceExistsAddress(IFACE_NAME & "-ROOT", False)
            If _CurrentRoot = -1 Then
                ReturnVal = CreateRootDevice()
                If ReturnVal <> "" Then Return ReturnVal
            Else
                WriteLog(DebugLog, "Device " & IFACE_NAME & "-ROOT" & " already exists. No need to create devices", 4)
            End If

            ' Now check if first Area device exist
            If hs.DeviceExistsAddress(AreaAddress(1), False) = -1 Then
                ReturnVal = CreateAreaDevice(1)
                If ReturnVal <> "" Then Return ReturnVal
            Else
                WriteLog(DebugLog, "Device " & AreaAddress(1) & " already exists. No need to create devices", 5)
            End If

            ' Now check if LCD device exist
            If hs.DeviceExistsAddress(LCDAddress(), False) = -1 Then
                ReturnVal = CreateLCDDevice()
                If ReturnVal <> "" Then Return ReturnVal
            Else
                WriteLog(DebugLog, "Device " & LCDAddress() & " already exists. No need to create device", 5)
            End If

            ' Check if Simple specific Devices exists
            If _UseSimpleProtocol Then
                ' Now check if LCD device exist
                If hs.DeviceExistsAddress(SimpleAddress(), False) = -1 Then
                    ReturnVal = CreateSimpleDevice()
                    If ReturnVal <> "" Then Return ReturnVal
                Else
                    WriteLog(DebugLog, "Device " & SimpleAddress() & " already exists. No need to create device", 5)
                End If
                ' Now check if Panel Time device exists
                If hs.DeviceExistsAddress(PanelTimeAddress(), False) = -1 Then
                    ReturnVal = CreatePanelTimeDevice()
                    If ReturnVal <> "" Then Return ReturnVal
                Else
                    WriteLog(DebugLog, "Device " & PanelTimeAddress() & " already exists. No need to create device", 5)
                End If
                ' Now check if System Voltage device exists
                If hs.DeviceExistsAddress(SystemVoltageAddress(), False) = -1 Then
                    ReturnVal = CreateSystemVoltageDevice()
                    If ReturnVal <> "" Then Return ReturnVal
                Else
                    WriteLog(DebugLog, "Device " & SystemVoltageAddress() & " already exists. No need to create device", 5)
                End If
                ' Now check if Battery Voltage device exists
                If hs.DeviceExistsAddress(BatteryVoltageAddress(), False) = -1 Then
                    ReturnVal = CreateBatteryVoltageDevice()
                    If ReturnVal <> "" Then Return ReturnVal
                Else
                    WriteLog(DebugLog, "Device " & BatteryVoltageAddress() & " already exists. No need to create device", 5)
                End If
                ' Now check if System Current device exists
                If hs.DeviceExistsAddress(SystemCurrentAddress(), False) = -1 Then
                    ReturnVal = CreateSystemCurrentDevice()
                    If ReturnVal <> "" Then Return ReturnVal
                Else
                    WriteLog(DebugLog, "Device " & SystemCurrentAddress() & " already exists. No need to create device", 5)
                End If
                ' Now check if Battery Charging Current device exists
                If hs.DeviceExistsAddress(BatteryCurrentAddress(), False) = -1 Then
                    ReturnVal = CreateBatteryCurrentDevice()
                    If ReturnVal <> "" Then Return ReturnVal
                Else
                    WriteLog(DebugLog, "Device " & BatteryCurrentAddress() & " already exists. No need to create device", 5)
                End If
                ' Now check if X10 Outputs exists
                For i As Integer = 1 To 8
                    If hs.DeviceExistsAddress(X10OutputAddress(i), False) = -1 Then
                        ReturnVal = CreateX10OutputDevice(i)
                        If ReturnVal <> "" Then Return ReturnVal
                    Else
                        WriteLog(DebugLog, "Device " & X10OutputAddress(i) & " already exists. No need to create device", 5)
                    End If
                Next
                ' Check if Panel Log device exists
                If hs.DeviceExistsAddress(PanelLogAddress(), False) = -1 Then
                    ReturnVal = CreatePanelLogDevice()
                    If ReturnVal <> "" Then Return ReturnVal
                Else
                    WriteLog(DebugLog, "Device " & PanelLogAddress() & " already exists. No need to create device", 5)
                End If
            End If


            ' Check Zone devices
            _NumberOfZones = NumberOfZones
            If _NumberOfZones > 0 Then CheckZoneDevices()

            ' Now check if any devices needs updating
            If LastVersion < CurrentVersion Then
                ReturnVal = UpdateDevices()
                If ReturnVal <> "" Then Return ReturnVal
                LastVersion = CurrentVersion
            End If

            ' Now open COM or TCP port for CRESTRON protocol
            If _UseComPort_Crestron Then
                ' Open Serial Port
                ReturnVal = OpenCOM_Crestron()
            Else
                OpenizTCPPort_Crestron()
            End If

            ' Read initial status
            SendTexecomCommand_Crestron("LSTATUS")
            Thread.Sleep(500)
            AstatusInProgress = True
            SendTexecomCommand_Crestron("ASTATUS")

            ' Now open COM or TCP port for Simple protocol
            If _UseSimpleProtocol Then
                If _UseComPort_Simple Then
                    ' Open Serial Port
                    ReturnVal = OpenCOM_Simple()

                    'If ReturnVal <> "" Then
                    '    WriteLog(ErrorLog, ReturnVal, 0)
                    '    Return ReturnVal
                    'End If
                Else
                    OpenizTCPPort_Simple()
                End If
                Simple_Login()
                Simple_PanelInfo()
                Thread.Sleep(500)
                _LogReadFromTimer = False
                Simple_PanelLogRead()
            End If

            ' Setup timer for Crestron Protocol
            If _PollingFrequency_Crestron > 0 Then
                Timer_Crestron = New System.Timers.Timer(1000 * _PollingFrequency_Crestron)
                Timer_Crestron.Enabled = True
                Timer_Crestron.Start()
            End If

            ' Setup timer for Simple Protocol
            If _PollingFrequency_Simple > 0 And _UseSimpleProtocol Then
                Timer_Simple = New System.Timers.Timer(1000 * _PollingFrequency_Simple)
                Timer_Simple.Enabled = True
                Timer_Simple.Start()
            End If

            ' Setup General timer
            GeneralTimer = New System.Timers.Timer(1000 * GeneralTimerInterval)
            GeneralTimer.Enabled = True
            GeneralTimer.Start()

            WriteLog(DebugLog, "Initialised, up And running ...", 5)
            Console.WriteLine("Initialised, up And running ...")

        Catch ex As Exception
            WriteLog(DebugLog, "Exception from izInit " & ex.Message, 0)
            Return "Exception from izInit " & ex.Message
        End Try

        Return ""
    End Function
    Friend Function izShutdown() As Boolean
        Thread.Sleep(1000)
        If _UseComPort_Crestron Then
            _rs232_Crestron.disconnect()
        Else
            CloseizTCPPort_Crestron()
        End If

        If _UseComPort_Simple Then
            _rs232_Simple.disconnect()
        Else
            CloseizTCPPort_Simple()
        End If

        LastVersion = CurrentVersion
        Return True
    End Function
#End Region

#Region "Device Creation" ' Set up as region only to keep Ini proc neat
    Friend Function UpdateDevices(Optional ByVal TypeToUpdate As String = "") As String
        Dim DeviceTypeString As String = ""
        Dim dvRef As Integer = -1
        Dim dvAdd As String = ""

        Try
            Dim dv As Scheduler.Classes.DeviceClass
            Dim EN As Scheduler.Classes.clsDeviceEnumeration
            EN = hs.GetDeviceEnumerator
            If EN Is Nothing Then
                Return "Error getting Enumerator in izInit"
            End If
            Do
                dv = EN.GetNext
                If dv Is Nothing Then Continue Do
                DeviceTypeString = dv.Device_Type_String(Nothing)
                dvRef = dv.Ref(Nothing)
                dvAdd = dv.Address(Nothing)

                If Left(DeviceTypeString, IFACE_NAME.Length) = IFACE_NAME Then
                    ' One of ours, now process it
                    Dim DeviceType As String = Right(DeviceTypeString, DeviceTypeString.Length - IFACE_NAME.Length)
                    If TypeToUpdate = "" Or TypeToUpdate = DeviceType Then
                        Dim DeviceIndex As Integer = Val(Right(dvAdd, 3))
                        Select Case DeviceType
                            Case _RootType
                                WriteLog(DebugLog, "Updating Root Device to latest version: " & CurrentVersion & " from version: " & LastVersion, 3)
                                CreateRootDevice(_CurrentRoot)
                            Case _LCDType
                                CreateLCDDevice(dvRef)
                            Case _AreaType
                                CreateAreaDevice(DeviceIndex, dvRef)
                            Case _ZoneType
                                CreateZoneDevice(DeviceIndex, dvRef)
                            Case _SimpleType
                                CreateSimpleDevice(dvRef)
                            Case _PanelTimeType
                                CreatePanelTimeDevice(dvRef)
                            Case _SystemVoltageType
                                CreateSystemVoltageDevice(dvRef)
                            Case _BatteryVoltageType
                                CreateBatteryVoltageDevice(dvRef)
                            Case _SystemCurrentType
                                CreateSystemCurrentDevice(dvRef)
                            Case _BatteryCurrentType
                                CreateBatteryCurrentDevice(dvRef)
                            Case _OutputX10Type
                                CreateX10OutputDevice(DeviceIndex, dvRef)
                            Case _PanelLogType
                                CreatePanelLogDevice(dvRef)
                        End Select
                    End If
                End If
            Loop Until EN.Finished
        Catch ex As Exception
            WriteLog("Error", "Exception updating device: " & ex.Message, 0)
            Return "Error updating devices to latest version"
        End Try
        Return ""
    End Function
    Friend Function AddAreaButtons(ByVal ExistingDeviceRef As Integer) As String
        Dim dv As Scheduler.Classes.DeviceClass = Nothing
        Dim ref As Integer
        Dim RtnMsg As String = ""


        ref = ExistingDeviceRef
        WriteLog(DebugLog, "Updating Area Buttons " & ExistingDeviceRef.ToString, 3)

        dv = hs.GetDeviceByRef(ref)

        AddVSPairs(ref, ePairStatusControl.Control, eAreaStatus.Arm, "Arm", 1, 1,,, ePairControlUse._DoorLock)
        If RtnMsg <> "" Then Return RtnMsg

        AddVSPairs(ref, ePairStatusControl.Control, eAreaStatus.Disarm, "Disarm", 1, 2,,, ePairControlUse._DoorUnLock)
        If RtnMsg <> "" Then Return RtnMsg

        AddVSPairs(ref, ePairStatusControl.Control, eAreaStatus.PartArm, "Part Arm", 1, 3)
        If RtnMsg <> "" Then Return RtnMsg

        AddVSPairs(ref, ePairStatusControl.Control, eAreaStatus.Reset, "Reset", 1, 4)
        If RtnMsg <> "" Then Return RtnMsg

        dv = Nothing

        Return ""
    End Function
    Friend Function RemoveAreaButtons(ByVal ExistingDeviceRef As Integer) As String
        Dim RtnMsg As String = ""

        WriteLog(DebugLog, "Updating Area Buttons " & ExistingDeviceRef.ToString, 3)

        hs.DeviceVSP_ClearAny(ExistingDeviceRef, eAreaStatus.Arm)
        hs.DeviceVSP_ClearAny(ExistingDeviceRef, eAreaStatus.Disarm)
        hs.DeviceVSP_ClearAny(ExistingDeviceRef, eAreaStatus.PartArm)
        hs.DeviceVSP_ClearAny(ExistingDeviceRef, eAreaStatus.Reset)

        Return ""
    End Function

    Private Function CreateRootDevice(Optional ByVal ExistingDeviceRef As Integer = -1) As String
        Dim dv As Scheduler.Classes.DeviceClass = Nothing
        Dim ref As Integer
        Dim RtnMsg As String = ""

        If ExistingDeviceRef <> -1 Then
            ref = ExistingDeviceRef
        Else
            ref = hs.NewDeviceRef(IFACE_NAME)
        End If

        dv = hs.GetDeviceByRef(ref)
        dv.Address(hs) = IFACE_NAME & _RootAddress
        If ExistingDeviceRef = -1 Then
            dv.Name(hs) = IFACE_NAME & _RootType
            dv.Location(hs) = IFACE_NAME
            dv.Location2(hs) = IFACE_NAME
        End If
        dv.Device_Type_String(hs) = IFACE_NAME & _RootType

        Dim DT As New DeviceTypeInfo
        DT.Device_API = DeviceTypeInfo.eDeviceAPI.Plug_In
        DT.Device_Type = DeviceTypeInfo.eDeviceType_GenericRoot
        DT.Device_SubType_Description = "Root Device"
        dv.DeviceType_Set(hs) = DT

        dv.Status_Support(hs) = False
        dv.Can_Dim(hs) = False
        dv.Interface(hs) = IFACE_NAME
        dv.MISC_Set(hs, Enums.dvMISC.SHOW_VALUES)
        dv.MISC_Clear(hs, Enums.dvMISC.NO_STATUS_DISPLAY)
        dv.MISC_Clear(hs, Enums.dvMISC.STATUS_ONLY)
        dv.MISC_Clear(hs, Enums.dvMISC.SET_DOES_NOT_CHANGE_LAST_CHANGE)
        dv.MISC_Clear(hs, Enums.dvMISC.MYHS_DEVICE_CHANGE_NOTIFY)
        dv.MISC_Clear(hs, Enums.dvMISC.INCLUDE_POWERFAIL)

        AddVSPairs(ref, ePairStatusControl.Control, eRootStatus.ArmStatus, "View Armed Status", 1, 2)

        dv.Last_Change(hs) = Now

        dv.Relationship(hs) = Enums.eRelationship.Parent_Root
        _CurrentRoot = ref

        dv = Nothing

        Return ""
    End Function
    Private Function CreateZoneDevice(ByRef Idx As Integer, Optional ByVal ExistingDeviceRef As Integer = -1) As String
        Dim dv As Scheduler.Classes.DeviceClass = Nothing
        Dim ref As Integer
        Dim RtnMsg As String = ""

        If ExistingDeviceRef <> -1 Then
            ref = ExistingDeviceRef
            WriteLog(DebugLog, "Updating Zone " & Idx.ToString, 3)
        Else
            ref = hs.NewDeviceRef(IFACE_NAME)
            WriteLog(DebugLog, "Creating Zone " & Idx.ToString, 3)
        End If

        dv = hs.GetDeviceByRef(ref)
        dv.Address(hs) = ZoneAddress(Idx)
        If ExistingDeviceRef = -1 Then dv = AddDeviceProperties(dv, _ZoneType, Idx)

        Dim DT As New DeviceTypeInfo
        DT.Device_API = DeviceTypeInfo.eDeviceAPI.Plug_In
        DT.Device_Type = DeviceTypeInfo.eDeviceAPI.Plug_In

        DT.Device_SubType_Description = "Zone"
        dv.DeviceType_Set(hs) = DT

        dv.Status_Support(hs) = False
        dv.Can_Dim(hs) = False
        dv.Interface(hs) = IFACE_NAME
        dv.MISC_Set(hs, Enums.dvMISC.SHOW_VALUES)

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, -1, "Unknown", 2, 4)
        If RtnMsg <> "" Then Return RtnMsg

        AddVSPairs(ref, ePairStatusControl.Status, eZoneStatus.Healthy, ZoneHealthyLabel, 2, 1)
        If RtnMsg <> "" Then Return RtnMsg

        AddVSPairs(ref, ePairStatusControl.Status, eZoneStatus.Active, ZoneActiveLabel, 2, 2)
        If RtnMsg <> "" Then Return RtnMsg

        AddVSPairs(ref, ePairStatusControl.Status, eZoneStatus.Tamper, "Tamper", 2, 3)
        If RtnMsg <> "" Then Return RtnMsg

        Dim GPair = New VGPair
        GPair.PairType = VSVGPairType.SingleValue
        GPair.Set_Value = eZoneStatus.Active
        GPair.Graphic = "/images/HomeSeer/contemporary/On-open-motion.png"
        hs.DeviceVGP_AddPair(ref, GPair)

        GPair = New VGPair
        GPair.PairType = VSVGPairType.SingleValue
        GPair.Set_Value = eZoneStatus.Healthy
        GPair.Graphic = "/images/HomeSeer/contemporary/off-closed-nomotion.png"
        hs.DeviceVGP_AddPair(ref, GPair)

        GPair = New VGPair
        GPair.PairType = VSVGPairType.SingleValue
        GPair.Set_Value = eZoneStatus.Tamper
        GPair.Graphic = "/images/HomeSeer/contemporary/alarmmalfunction.png"
        hs.DeviceVGP_AddPair(ref, GPair)

        hs.SetDeviceValueByRef(ref, -1, True)

        dv.Relationship(hs) = Enums.eRelationship.Child
        dv.AssociatedDevice_Add(hs, _CurrentRoot)
        Dim RootDev As Scheduler.Classes.DeviceClass = Nothing
        RootDev = hs.GetDeviceByRef(_CurrentRoot)
        RootDev.AssociatedDevice_Add(hs, ref)
        RootDev = Nothing

        dv.Last_Change(hs) = Now

        dv = Nothing

        Return ""
    End Function
    Private Function CreateZone2Device(ByRef Idx As Integer, Optional ByVal ExistingDeviceRef As Integer = -1) As String
        Dim dv As Scheduler.Classes.DeviceClass = Nothing
        Dim ref As Integer
        Dim RtnMsg As String = ""

        If ExistingDeviceRef <> -1 Then
            ref = ExistingDeviceRef
            WriteLog(DebugLog, "Updating Zone " & Idx.ToString, 3)
        Else
            ref = hs.NewDeviceRef(IFACE_NAME)
            WriteLog(DebugLog, "Creating Zone " & Idx.ToString, 3)
        End If

        dv = hs.GetDeviceByRef(ref)
        dv.Address(hs) = ZoneAddress(Idx)
        If ExistingDeviceRef = -1 Then dv = AddDeviceProperties(dv, _ZoneType, Idx)

        Dim DT As New DeviceTypeInfo
        DT.Device_API = DeviceTypeInfo.eDeviceAPI.Plug_In
        DT.Device_Type = DeviceTypeInfo.eDeviceAPI.Plug_In

        DT.Device_SubType_Description = "Zone"
        dv.DeviceType_Set(hs) = DT

        dv.Status_Support(hs) = False
        dv.Can_Dim(hs) = False
        dv.Interface(hs) = IFACE_NAME
        dv.MISC_Set(hs, Enums.dvMISC.SHOW_VALUES)

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, -1, "Unknown", 2, 4)
        If RtnMsg <> "" Then Return RtnMsg

        AddVSPairs(ref, ePairStatusControl.Status, eZoneStatus.Healthy, "Healthy", 2, 1)
        If RtnMsg <> "" Then Return RtnMsg

        AddVSPairs(ref, ePairStatusControl.Status, eZoneStatus.Active, "Active", 2, 2)
        If RtnMsg <> "" Then Return RtnMsg

        AddVSPairs(ref, ePairStatusControl.Status, eZoneStatus.Tamper, "Tamper", 2, 3)
        If RtnMsg <> "" Then Return RtnMsg

        Dim GPair = New VGPair
        GPair.PairType = VSVGPairType.SingleValue
        GPair.Set_Value = eZoneStatus.Active
        GPair.Graphic = "/images/HomeSeer/contemporary/On-open-motion.png"
        hs.DeviceVGP_AddPair(ref, GPair)

        GPair = New VGPair
        GPair.PairType = VSVGPairType.SingleValue
        GPair.Set_Value = eZoneStatus.Healthy
        GPair.Graphic = "/images/HomeSeer/contemporary/off-closed-nomotion.png"
        hs.DeviceVGP_AddPair(ref, GPair)

        GPair = New VGPair
        GPair.PairType = VSVGPairType.SingleValue
        GPair.Set_Value = eZoneStatus.Tamper
        GPair.Graphic = "/images/HomeSeer/contemporary/alarmmalfunction.png"
        hs.DeviceVGP_AddPair(ref, GPair)

        hs.SetDeviceValueByRef(ref, -1, True)

        dv.Relationship(hs) = Enums.eRelationship.Child
        dv.AssociatedDevice_Add(hs, _CurrentRoot)
        Dim RootDev As Scheduler.Classes.DeviceClass = Nothing
        RootDev = hs.GetDeviceByRef(_CurrentRoot)
        RootDev.AssociatedDevice_Add(hs, ref)
        RootDev = Nothing

        dv.Last_Change(hs) = Now

        dv = Nothing

        Return ""
    End Function
    Friend Sub CheckZoneDevices()
        Dim Idx As Integer = 0
        If _NumberOfZones < 1 Then
            WriteLog(ErrorLog, "CheckZoneDevices called but Number Of Zones Not Set On settings page", 0)
            Exit Sub
        End If
        Dim dvAddr As String = ""
        For Idx = 1 To NumberOfZones
            dvAddr = ZoneAddress(Idx)
            If hs.DeviceExistsAddress(dvAddr, False) = -1 Then
                WriteLog(DebugLog, "Creating device For Zone " & Idx.ToString, 5)
                CreateZoneDevice(Idx)
            Else
                WriteLog(DebugLog, "Device For Zone " & Idx.ToString & " already exists", 5)
            End If

        Next
    End Sub
    Private Function CreateAreaDevice(ByRef Idx As Integer, Optional ByVal ExistingDeviceRef As Integer = -1) As String
        Dim dv As Scheduler.Classes.DeviceClass = Nothing
        Dim ref As Integer
        Dim RtnMsg As String = ""

        If ExistingDeviceRef <> -1 Then
            ref = ExistingDeviceRef
            WriteLog(DebugLog, "Updating Area " & Idx.ToString, 3)
        Else
            ref = hs.NewDeviceRef(IFACE_NAME)
            WriteLog(DebugLog, "Creating Area " & Idx.ToString, 3)
        End If

        dv = hs.GetDeviceByRef(ref)
        dv.Address(hs) = AreaAddress(Idx)
        If ExistingDeviceRef = -1 Then dv = AddDeviceProperties(dv, _AreaType, Idx)

        Dim DT As New DeviceTypeInfo
        DT.Device_API = DeviceTypeInfo.eDeviceAPI.Plug_In
        DT.Device_Type = DeviceTypeInfo.eDeviceAPI.Plug_In

        DT.Device_SubType_Description = Trim(_AreaType)
        dv.DeviceType_Set(hs) = DT

        dv.Status_Support(hs) = False
        dv.Can_Dim(hs) = False
        dv.Interface(hs) = IFACE_NAME
        dv.MISC_Set(hs, Enums.dvMISC.SHOW_VALUES)

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, -1, "Unknown", 2, 4)
        If RtnMsg <> "" Then Return RtnMsg

        AddVSPairs(ref, ePairStatusControl.Status, eAreaStatus.Armed, "Armed", 2, 1)
        If RtnMsg <> "" Then Return RtnMsg

        AddVSPairs(ref, ePairStatusControl.Status, eAreaStatus.Disarmed, "Disarmed", 2, 2)
        If RtnMsg <> "" Then Return RtnMsg

        AddVSPairs(ref, ePairStatusControl.Status, eAreaStatus.PartArmed, "Part Armed", 2, 5)
        If RtnMsg <> "" Then Return RtnMsg

        Dim GPair = New VGPair
        GPair.PairType = VSVGPairType.SingleValue
        GPair.Set_Value = eAreaStatus.Armed
        GPair.Graphic = "/images/HomeSeer/contemporary/armed-away.png"
        hs.DeviceVGP_AddPair(ref, GPair)

        GPair = New VGPair
        GPair.PairType = VSVGPairType.SingleValue
        GPair.Set_Value = eAreaStatus.Disarmed
        GPair.Graphic = "/images/HomeSeer/contemporary/useropening.png"
        hs.DeviceVGP_AddPair(ref, GPair)

        hs.SetDeviceValueByRef(ref, -1, True)

        dv.Relationship(hs) = Enums.eRelationship.Child
        dv.AssociatedDevice_Add(hs, _CurrentRoot)
        Dim RootDev As Scheduler.Classes.DeviceClass = Nothing
        RootDev = hs.GetDeviceByRef(_CurrentRoot)
        RootDev.AssociatedDevice_Add(hs, ref)
        RootDev = Nothing

        dv.Last_Change(hs) = Now

        dv = Nothing

        If _UseSimpleProtocol Then AddAreaButtons(ref) Else RemoveAreaButtons(ref)

        Return ""
    End Function
    Private Function CreateLCDDevice(Optional ByVal ExistingDeviceRef As Integer = -1) As String
        Dim dv As Scheduler.Classes.DeviceClass = Nothing
        Dim ref As Integer
        Dim RtnMsg As String = ""

        If ExistingDeviceRef <> -1 Then
            ref = ExistingDeviceRef
            WriteLog(DebugLog, "Updating LCD Device", 3)
        Else
            ref = hs.NewDeviceRef(IFACE_NAME)
            WriteLog(DebugLog, "Creating LCD Device", 3)
        End If

        dv = hs.GetDeviceByRef(ref)
        dv.Address(hs) = LCDAddress
        If ExistingDeviceRef = -1 Then dv = AddDeviceProperties(dv, _LCDType)

        Dim DT As New DeviceTypeInfo
        DT.Device_API = DeviceTypeInfo.eDeviceAPI.Plug_In
        DT.Device_Type = DeviceTypeInfo.eDeviceAPI.Plug_In

        DT.Device_SubType_Description = Trim(_LCDType)
        dv.DeviceType_Set(hs) = DT

        dv.Status_Support(hs) = False
        dv.Can_Dim(hs) = False
        dv.Interface(hs) = IFACE_NAME
        dv.MISC_Set(hs, Enums.dvMISC.SHOW_VALUES)

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, -1, "Unknown", 2, 4)
        If RtnMsg <> "" Then Return RtnMsg

        AddVSPairs(ref, ePairStatusControl.Control, eLCD.ViewStatus, "Read LCD", 1, 1)
        If RtnMsg <> "" Then Return RtnMsg

        Dim MyVSP As New VSPair(ePairStatusControl.Control)
        Dim i As Integer
        For i = 0 To _SendKeyPressLabel.Length - 1
            MyVSP.PairType = VSVGPairType.SingleValue
            MyVSP.Render_Location.Row = 1
            MyVSP.Render_Location.Column = 1
            MyVSP.Render_Location.ColumnSpan = 0
            MyVSP.Value = i
            MyVSP.Status = _SendKeyPressLabel(i)
            MyVSP.IncludeValues = False
            MyVSP.Render = Enums.CAPIControlType.Single_Text_from_List
            hs.DeviceVSP_AddPair(ref, MyVSP)
        Next

        hs.SetDeviceValueByRef(ref, -1, True)

        dv.Relationship(hs) = Enums.eRelationship.Child
        dv.AssociatedDevice_Add(hs, _CurrentRoot)
        Dim RootDev As Scheduler.Classes.DeviceClass = Nothing
        RootDev = hs.GetDeviceByRef(_CurrentRoot)
        RootDev.AssociatedDevice_Add(hs, ref)
        RootDev = Nothing

        dv.Last_Change(hs) = Now

        dv = Nothing

        Return ""
    End Function
    Private Function CreateSimpleDevice(Optional ByVal ExistingDeviceRef As Integer = -1) As String
        Dim dv As Scheduler.Classes.DeviceClass = Nothing
        Dim ref As Integer
        Dim RtnMsg As String = ""

        If ExistingDeviceRef <> -1 Then
            ref = ExistingDeviceRef
            WriteLog(DebugLog, "Updating Simple ", 3)
        Else
            ref = hs.NewDeviceRef(IFACE_NAME)
            WriteLog(DebugLog, "Creating Simple", 3)
        End If

        dv = hs.GetDeviceByRef(ref)
        dv.Address(hs) = SimpleAddress
        If ExistingDeviceRef = -1 Then dv = AddDeviceProperties(dv, _SimpleType)

        Dim DT As New DeviceTypeInfo
        DT.Device_API = DeviceTypeInfo.eDeviceAPI.Plug_In
        DT.Device_Type = DeviceTypeInfo.eDeviceAPI.Plug_In

        DT.Device_SubType_Description = Trim(_SimpleType)
        dv.DeviceType_Set(hs) = DT

        dv.Status_Support(hs) = False
        dv.Can_Dim(hs) = False
        dv.Interface(hs) = IFACE_NAME
        dv.MISC_Set(hs, Enums.dvMISC.SHOW_VALUES)

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, eSimpleDevice.Unknown, "Unknown", 1, 3)
        If RtnMsg <> "" Then Return RtnMsg

        AddVSPairs(ref, ePairStatusControl.Status, eSimpleDevice.LoggedIn, "Logged In", 1, 1)
        If RtnMsg <> "" Then Return RtnMsg

        AddVSPairs(ref, ePairStatusControl.Status, eSimpleDevice.Error, "Error", 1, 2)
        If RtnMsg <> "" Then Return RtnMsg

        hs.SetDeviceValueByRef(ref, -1, True)

        dv.Relationship(hs) = Enums.eRelationship.Child
        dv.AssociatedDevice_Add(hs, _CurrentRoot)
        Dim RootDev As Scheduler.Classes.DeviceClass = Nothing
        RootDev = hs.GetDeviceByRef(_CurrentRoot)
        RootDev.AssociatedDevice_Add(hs, ref)
        RootDev = Nothing

        dv.Last_Change(hs) = Now

        dv = Nothing

        Return ""
    End Function
    Private Function CreatePanelTimeDevice(Optional ByVal ExistingDeviceRef As Integer = -1) As String
        Dim dv As Scheduler.Classes.DeviceClass = Nothing
        Dim ref As Integer
        Dim RtnMsg As String = ""

        If ExistingDeviceRef <> -1 Then
            ref = ExistingDeviceRef
            WriteLog(DebugLog, "Updating PanelTime Device", 3)
        Else
            ref = hs.NewDeviceRef(IFACE_NAME)
            WriteLog(DebugLog, "Creating PanelTime Device", 3)
        End If

        dv = hs.GetDeviceByRef(ref)
        dv.Address(hs) = PanelTimeAddress
        If ExistingDeviceRef = -1 Then dv = AddDeviceProperties(dv, _PanelTimeType)

        Dim DT As New DeviceTypeInfo
        DT.Device_API = DeviceTypeInfo.eDeviceAPI.Plug_In
        DT.Device_Type = DeviceTypeInfo.eDeviceAPI.Plug_In

        DT.Device_SubType_Description = Trim(_PanelTimeType)
        dv.DeviceType_Set(hs) = DT

        dv.Status_Support(hs) = False
        dv.Can_Dim(hs) = False
        dv.Interface(hs) = IFACE_NAME
        dv.MISC_Set(hs, Enums.dvMISC.SHOW_VALUES)

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, ePanelTimeDevice.Unknown, ePanelTimeDevice.Unknown.ToString, 2, 4)
        If RtnMsg <> "" Then Return RtnMsg

        AddVSPairs(ref, ePairStatusControl.Control, ePanelTimeDevice.ReadTime, "Read Time", 1, 1)
        If RtnMsg <> "" Then Return RtnMsg

        AddVSPairs(ref, ePairStatusControl.Control, ePanelTimeDevice.SetTime, "Set Time", 1, 2)
        If RtnMsg <> "" Then Return RtnMsg

        hs.SetDeviceValueByRef(ref, -1, True)

        dv.Relationship(hs) = Enums.eRelationship.Child
        dv.AssociatedDevice_Add(hs, _CurrentRoot)
        Dim RootDev As Scheduler.Classes.DeviceClass = Nothing
        RootDev = hs.GetDeviceByRef(_CurrentRoot)
        RootDev.AssociatedDevice_Add(hs, ref)
        RootDev = Nothing

        dv.Last_Change(hs) = Now

        dv = Nothing

        Return ""
    End Function
    Private Function CreateSystemVoltageDevice(Optional ByVal ExistingDeviceRef As Integer = -1) As String
        Dim dv As Scheduler.Classes.DeviceClass = Nothing
        Dim ref As Integer
        Dim RtnMsg As String = ""

        If ExistingDeviceRef <> -1 Then
            ref = ExistingDeviceRef
            WriteLog(DebugLog, "Updating SystemVoltageDevice", 3)
        Else
            ref = hs.NewDeviceRef(IFACE_NAME)
            WriteLog(DebugLog, "Creating SystemVoltageDevice", 3)
        End If

        dv = hs.GetDeviceByRef(ref)
        dv.Address(hs) = SystemVoltageAddress
        If ExistingDeviceRef = -1 Then dv = AddDeviceProperties(dv, _SystemVoltageType)

        Dim DT As New DeviceTypeInfo
        DT.Device_API = DeviceTypeInfo.eDeviceAPI.Plug_In
        DT.Device_Type = DeviceTypeInfo.eDeviceAPI.Plug_In

        DT.Device_SubType_Description = Trim(_SystemVoltageType)
        dv.DeviceType_Set(hs) = DT

        dv.Status_Support(hs) = False
        dv.Can_Dim(hs) = False
        dv.Interface(hs) = IFACE_NAME
        dv.MISC_Set(hs, Enums.dvMISC.SHOW_VALUES)


        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, eVoltages.Unknown, eVoltages.Unknown.ToString, 2, 4)
        If RtnMsg <> "" Then Return RtnMsg

        AddVSPairs(ref, ePairStatusControl.Control, eVoltages.Read, "Read Voltage", 1, 1)
        hs.SetDeviceValueByRef(ref, -1, True)

        dv.Relationship(hs) = Enums.eRelationship.Child
        dv.AssociatedDevice_Add(hs, _CurrentRoot)
        Dim RootDev As Scheduler.Classes.DeviceClass = Nothing
        RootDev = hs.GetDeviceByRef(_CurrentRoot)
        RootDev.AssociatedDevice_Add(hs, ref)
        RootDev = Nothing

        dv.Last_Change(hs) = Now

        dv = Nothing

        Return ""
    End Function
    Private Function CreateBatteryVoltageDevice(Optional ByVal ExistingDeviceRef As Integer = -1) As String
        Dim dv As Scheduler.Classes.DeviceClass = Nothing
        Dim ref As Integer
        Dim RtnMsg As String = ""

        If ExistingDeviceRef <> -1 Then
            ref = ExistingDeviceRef
            WriteLog(DebugLog, "Updating BatteryVoltageDevice", 3)
        Else
            ref = hs.NewDeviceRef(IFACE_NAME)
            WriteLog(DebugLog, "Creating BatteryVoltageDevice", 3)
        End If

        dv = hs.GetDeviceByRef(ref)
        dv.Address(hs) = BatteryVoltageAddress
        If ExistingDeviceRef = -1 Then dv = AddDeviceProperties(dv, _BatteryVoltageType)

        Dim DT As New DeviceTypeInfo
        DT.Device_API = DeviceTypeInfo.eDeviceAPI.Plug_In
        DT.Device_Type = DeviceTypeInfo.eDeviceAPI.Plug_In

        DT.Device_SubType_Description = Trim(_BatteryVoltageType)
        dv.DeviceType_Set(hs) = DT

        dv.Status_Support(hs) = False
        dv.Can_Dim(hs) = False
        dv.Interface(hs) = IFACE_NAME
        dv.MISC_Set(hs, Enums.dvMISC.SHOW_VALUES)


        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, eVoltages.Unknown, eVoltages.Unknown.ToString, 2, 4)
        If RtnMsg <> "" Then Return RtnMsg

        AddVSPairs(ref, ePairStatusControl.Control, eVoltages.Read, "Read Voltage", 1, 1)
        hs.SetDeviceValueByRef(ref, -1, True)

        dv.Relationship(hs) = Enums.eRelationship.Child
        dv.AssociatedDevice_Add(hs, _CurrentRoot)
        Dim RootDev As Scheduler.Classes.DeviceClass = Nothing
        RootDev = hs.GetDeviceByRef(_CurrentRoot)
        RootDev.AssociatedDevice_Add(hs, ref)
        RootDev = Nothing

        dv.Last_Change(hs) = Now

        dv = Nothing

        Return ""
    End Function
    Private Function CreateSystemCurrentDevice(Optional ByVal ExistingDeviceRef As Integer = -1) As String
        Dim dv As Scheduler.Classes.DeviceClass = Nothing
        Dim ref As Integer
        Dim RtnMsg As String = ""

        If ExistingDeviceRef <> -1 Then
            ref = ExistingDeviceRef
            WriteLog(DebugLog, "Updating SystemCurrentDevice", 3)
        Else
            ref = hs.NewDeviceRef(IFACE_NAME)
            WriteLog(DebugLog, "Creating SystemCurrentDevice", 3)
        End If

        dv = hs.GetDeviceByRef(ref)
        dv.Address(hs) = SystemCurrentAddress
        If ExistingDeviceRef = -1 Then dv = AddDeviceProperties(dv, _SystemCurrentType)

        Dim DT As New DeviceTypeInfo
        DT.Device_API = DeviceTypeInfo.eDeviceAPI.Plug_In
        DT.Device_Type = DeviceTypeInfo.eDeviceAPI.Plug_In

        DT.Device_SubType_Description = Trim(_SystemCurrentType)
        dv.DeviceType_Set(hs) = DT

        dv.Status_Support(hs) = False
        dv.Can_Dim(hs) = False
        dv.Interface(hs) = IFACE_NAME
        dv.MISC_Set(hs, Enums.dvMISC.SHOW_VALUES)


        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, eVoltages.Unknown, eVoltages.Unknown.ToString, 2, 4)
        If RtnMsg <> "" Then Return RtnMsg

        AddVSPairs(ref, ePairStatusControl.Control, eVoltages.Read, "Read Current", 1, 1)
        hs.SetDeviceValueByRef(ref, -1, True)

        dv.Relationship(hs) = Enums.eRelationship.Child
        dv.AssociatedDevice_Add(hs, _CurrentRoot)
        Dim RootDev As Scheduler.Classes.DeviceClass = Nothing
        RootDev = hs.GetDeviceByRef(_CurrentRoot)
        RootDev.AssociatedDevice_Add(hs, ref)
        RootDev = Nothing

        dv.Last_Change(hs) = Now

        dv = Nothing

        Return ""
    End Function
    Private Function CreateBatteryCurrentDevice(Optional ByVal ExistingDeviceRef As Integer = -1) As String
        Dim dv As Scheduler.Classes.DeviceClass = Nothing
        Dim ref As Integer
        Dim RtnMsg As String = ""

        If ExistingDeviceRef <> -1 Then
            ref = ExistingDeviceRef
            WriteLog(DebugLog, "Updating BatteryChargingCurrentDevice", 3)
        Else
            ref = hs.NewDeviceRef(IFACE_NAME)
            WriteLog(DebugLog, "Creating BatteryChargingCurrentDevice", 3)
        End If

        dv = hs.GetDeviceByRef(ref)
        dv.Address(hs) = BatteryCurrentAddress
        If ExistingDeviceRef = -1 Then dv = AddDeviceProperties(dv, _BatteryCurrentType)

        Dim DT As New DeviceTypeInfo
        DT.Device_API = DeviceTypeInfo.eDeviceAPI.Plug_In
        DT.Device_Type = DeviceTypeInfo.eDeviceAPI.Plug_In

        DT.Device_SubType_Description = Trim(_BatteryCurrentType)
        dv.DeviceType_Set(hs) = DT

        dv.Status_Support(hs) = False
        dv.Can_Dim(hs) = False
        dv.Interface(hs) = IFACE_NAME
        dv.MISC_Set(hs, Enums.dvMISC.SHOW_VALUES)


        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, eVoltages.Unknown, eVoltages.Unknown.ToString, 2, 4)
        If RtnMsg <> "" Then Return RtnMsg

        AddVSPairs(ref, ePairStatusControl.Control, eVoltages.Read, "Read Current", 1, 1)
        hs.SetDeviceValueByRef(ref, -1, True)

        dv.Relationship(hs) = Enums.eRelationship.Child
        dv.AssociatedDevice_Add(hs, _CurrentRoot)
        Dim RootDev As Scheduler.Classes.DeviceClass = Nothing
        RootDev = hs.GetDeviceByRef(_CurrentRoot)
        RootDev.AssociatedDevice_Add(hs, ref)
        RootDev = Nothing

        dv.Last_Change(hs) = Now

        dv = Nothing

        Return ""
    End Function
    Private Function CreateX10OutputDevice(ByRef Idx As Integer, Optional ByVal ExistingDeviceRef As Integer = -1) As String
        Dim dv As Scheduler.Classes.DeviceClass = Nothing
        Dim ref As Integer
        Dim RtnMsg As String = ""

        If ExistingDeviceRef <> -1 Then
            ref = ExistingDeviceRef
            WriteLog(DebugLog, "Updating X10 Output Device " & Idx.ToString, 3)
        Else
            ref = hs.NewDeviceRef(IFACE_NAME)
            WriteLog(DebugLog, "Creating X10 Output Device " & Idx.ToString, 3)
        End If

        dv = hs.GetDeviceByRef(ref)
        dv.Address(hs) = X10OutputAddress(Idx)
        If ExistingDeviceRef = -1 Then dv = AddDeviceProperties(dv, _OutputX10Type, Idx)

        Dim DT As New DeviceTypeInfo
        DT.Device_API = DeviceTypeInfo.eDeviceAPI.Plug_In
        DT.Device_Type = DeviceTypeInfo.eDeviceAPI.Plug_In

        DT.Device_SubType_Description = "X10 Output"
        dv.DeviceType_Set(hs) = DT

        dv.Status_Support(hs) = False
        dv.Can_Dim(hs) = False
        dv.Interface(hs) = IFACE_NAME
        dv.MISC_Set(hs, Enums.dvMISC.SHOW_VALUES)

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, -1, "Unknown", 2, 4)
        If RtnMsg <> "" Then Return RtnMsg

        AddVSPairs(ref, ePairStatusControl.Both, eX10.On, "On", 1, 1,,, ePairControlUse._On)
        If RtnMsg <> "" Then Return RtnMsg

        AddVSPairs(ref, ePairStatusControl.Both, eX10.Off, "Off", 1, 2,,, ePairControlUse._Off)
        If RtnMsg <> "" Then Return RtnMsg

        hs.SetDeviceValueByRef(ref, -1, True)

        dv.Relationship(hs) = Enums.eRelationship.Child
        dv.AssociatedDevice_Add(hs, _CurrentRoot)
        Dim RootDev As Scheduler.Classes.DeviceClass = Nothing
        RootDev = hs.GetDeviceByRef(_CurrentRoot)
        RootDev.AssociatedDevice_Add(hs, ref)
        RootDev = Nothing

        dv.Last_Change(hs) = Now

        dv = Nothing

        Return ""
    End Function
    Private Function CreatePanelLogDevice(Optional ByVal ExistingDeviceRef As Integer = -1) As String
        Dim dv As Scheduler.Classes.DeviceClass = Nothing
        Dim ref As Integer
        Dim RtnMsg As String = ""

        If ExistingDeviceRef <> -1 Then
            ref = ExistingDeviceRef
            WriteLog(DebugLog, "Updating Panel Log Device", 3)
        Else
            ref = hs.NewDeviceRef(IFACE_NAME)
            WriteLog(DebugLog, "Creating Panel Log Device", 3)
        End If

        dv = hs.GetDeviceByRef(ref)
        dv.Address(hs) = PanelLogAddress
        If ExistingDeviceRef = -1 Then dv = AddDeviceProperties(dv, _PanelLogType)

        Dim DT As New DeviceTypeInfo
        DT.Device_API = DeviceTypeInfo.eDeviceAPI.Plug_In
        DT.Device_Type = DeviceTypeInfo.eDeviceAPI.Plug_In

        DT.Device_SubType_Description = Trim(_PanelLogType)
        dv.DeviceType_Set(hs) = DT

        dv.Status_Support(hs) = False
        dv.Can_Dim(hs) = False
        dv.Interface(hs) = IFACE_NAME
        dv.MISC_Set(hs, Enums.dvMISC.SHOW_VALUES)

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, ePanelLog.Unknown, "Unknown", 2, 4)
        If RtnMsg <> "" Then Return RtnMsg

        AddVSPairs(ref, ePairStatusControl.Control, ePanelLog.Up, "Up", 1, 1)
        If RtnMsg <> "" Then Return RtnMsg

        AddVSPairs(ref, ePairStatusControl.Control, ePanelLog.Down, "Down", 1, 2)
        If RtnMsg <> "" Then Return RtnMsg

        AddVSPairs(ref, ePairStatusControl.Control, ePanelLog.Read, "Read Log", 1, 3)
        If RtnMsg <> "" Then Return RtnMsg

        hs.SetDeviceValueByRef(ref, ePanelLog.Unknown, True)

        dv.Relationship(hs) = Enums.eRelationship.Child
        dv.AssociatedDevice_Add(hs, _CurrentRoot)
        Dim RootDev As Scheduler.Classes.DeviceClass = Nothing
        RootDev = hs.GetDeviceByRef(_CurrentRoot)
        RootDev.AssociatedDevice_Add(hs, ref)
        RootDev = Nothing

        dv.Last_Change(hs) = Now

        dv = Nothing

        Return ""
    End Function
#End Region

#Region "Device Update Procedures"
    Friend Sub UpdateHSDeviceValue(ByRef DeviceAddress As String, ByRef Value As Double)
        Dim DeviceRef As Integer = hs.DeviceExistsAddress(DeviceAddress, False)

        If DeviceRef <> -1 Then
            hs.SetDeviceValueByRef(DeviceRef, Value, True)
            WriteLog(DebugLog, "Device " & DeviceAddress & " updated", 5)
        Else
            WriteLog(DebugLog, "Can't update Device: " & DeviceAddress & " as this device does not exist", 5)
        End If
    End Sub
    Friend Sub UpdateHSDeviceString(ByRef DeviceAddress As String, ByRef Value As String)
        Dim DeviceRef As Integer = hs.DeviceExistsAddress(DeviceAddress, False)

        If DeviceRef <> -1 Then
            hs.SetDeviceString(DeviceRef, Value, True)
            WriteLog(DebugLog, "Device: " & DeviceAddress & " updated", 5)
        Else
            WriteLog(DebugLog, "Can't update Device: " & DeviceAddress & " as this device does not exist", 5)
        End If
    End Sub

#End Region

    ' CRESTON PROTOCOL STUFF BELOW

#Region "izTexecom Commands Crestron"
    Friend Sub SendTexecomCommand_Crestron(Cmd As String, Optional ByVal SendEnd As Boolean = True)
        Dim SendStr() As Char = _CmdStart_Crestron
        SendStr = _CmdStart_Crestron & Cmd
        If SendEnd Then SendStr = SendStr & _CmdEnd_Crestron

        Dim SendBytes() As Byte = StrToByteArray(SendStr)

        Try
            If _UseComPort_Crestron Then
                WriteLog(DebugLog, "Send command " & SendStr & " via serial port", 3)
                _rs232_Crestron.SendData(SendBytes)
            Else
                WriteLog(DebugLog, "Send command " & SendStr & " via TCP/IP", 3)
                izTCPClient_Crestron.Stream.Write(SendBytes, 0, SendBytes.Length)
            End If

            Thread.Sleep(_CommandDelay_Crestron)

        Catch ex As Exception
            WriteLog(ErrorLog, "Exception from Send Command. Error ID " & ex.Message, 0)
            ' Attempt to re-open port as this is most likely the cause
            If _UseComPort_Crestron Then
                _rs232_Crestron.disconnect()
                OpenCOM_Crestron()
            Else
                CloseizTCPPort_Crestron()
                OpenizTCPPort_Crestron()
            End If
        End Try
    End Sub
    Private Sub ProcessPacket_Crestron(ByRef TexecomPacket As String)
        ' Valid response
        Dim DeviceNo As Integer = 0
        Dim Action As Integer = 0

        Dim tempval As Integer = TexecomPacket.Length

        Select Case TexecomPacket.Length
            Case 5 ' Zone, Armed, Disarmed status
                Select Case TexecomPacket(0)
                    Case "Z" ' Zone Status Changed
                        DeviceNo = Val(TexecomPacket.Substring(1, 3))
                        Action = Val(TexecomPacket(4))
                        WriteLog(DebugLog, "Updating Zone " & DeviceNo & " With Action " & Action, 3)
                        UpdateHSDeviceValue(ZoneAddress(DeviceNo), Action)
                    Case "A" ' Armed Status Changed
                        DeviceNo = Val(TexecomPacket.Substring(1, 3))
                        If hs.DeviceExistsAddress(AreaAddress(DeviceNo), False) = -1 Then CreateAreaDevice(DeviceNo)
                        WriteLog(DebugLog, "Updating Area " & DeviceNo & " With Armed Action", 3)
                        UpdateHSDeviceValue(AreaAddress(DeviceNo), eAreaStatus.Armed)
                    Case "D" ' Disarmed Status Changed
                        DeviceNo = Val(TexecomPacket.Substring(1, 3))
                        If hs.DeviceExistsAddress(AreaAddress(DeviceNo), False) = -1 Then CreateAreaDevice(DeviceNo)
                        WriteLog(DebugLog, "Updating Area " & DeviceNo & " With Disarmed Action", 3)
                        UpdateHSDeviceValue(AreaAddress(DeviceNo), eAreaStatus.Disarmed)
                End Select
            Case 7 ' Zone Armed, Disarmed with new protocol format
                Select Case TexecomPacket(0)
                    Case "A" ' Armed Status Changed
                        DeviceNo = Val(TexecomPacket.Substring(1, 3))
                        If hs.DeviceExistsAddress(AreaAddress(DeviceNo), False) = -1 Then CreateAreaDevice(DeviceNo)
                        WriteLog(DebugLog, "Updating Area " & DeviceNo & " With Armed Action", 3)
                        UpdateHSDeviceValue(AreaAddress(DeviceNo), eAreaStatus.Armed)
                    Case "D" ' Disarmed Status Changed
                        DeviceNo = Val(TexecomPacket.Substring(1, 3))
                        If hs.DeviceExistsAddress(AreaAddress(DeviceNo), False) = -1 Then CreateAreaDevice(DeviceNo)
                        WriteLog(DebugLog, "Updating Area " & DeviceNo & " With Disarmed Action", 3)
                        UpdateHSDeviceValue(AreaAddress(DeviceNo), eAreaStatus.Disarmed)
                End Select
            Case 32 ' LCD Status
                        UpdateHSDeviceString(LCDAddress, TexecomPacket)
                    Case Else  ' Area armed status
                        If AstatusInProgress Then
                            Dim AreaEnumerator As Integer
                            Dim Areas As Char() = TexecomPacket
                            For AreaEnumerator = 1 To TexecomPacket.Length
                                Dim X As String = AreaAddress(AreaEnumerator)
                                Dim Y As String = Areas(AreaEnumerator - 1)
                                If hs.DeviceExistsAddress(AreaAddress(AreaEnumerator), False) = -1 Then CreateAreaDevice(AreaEnumerator)
                                Select Case Areas(AreaEnumerator - 1)
                                    Case "Y"
                                        UpdateHSDeviceValue(AreaAddress(AreaEnumerator), eAreaStatus.Armed)
                                        AstatusInProgress = False
                                    Case "N"
                                        UpdateHSDeviceValue(AreaAddress(AreaEnumerator), eAreaStatus.Disarmed)
                                        AstatusInProgress = False
                                    Case Else
                                        WriteLog(ErrorLog, "Invalid reponse In expected Area Status report. Packet received " & TexecomPacket, 0)
                                        Exit Sub
                                End Select
                            Next
                        Else
                            WriteLog(ErrorLog, "Apparently valid, but unknown panel response received " & TexecomPacket, 0)
                        End If
                End Select
    End Sub
    Friend Sub ProcessIncomingData_Crestron(ByVal IncomingData As String)
        Dim PanelResponse As String = izComLeftOverData_Crestron & IncomingData
        Dim AnalysisComplete As Boolean = False
        Do
            If InStr(PanelResponse, Chr(34)) > 0 And InStr(PanelResponse, Chr(10)) > 0 Then ' We have found both a starting and end character! 
                'Dim NewPacket As String = PanelResponse.Substring(InStr(PanelResponse, Chr(34)), InStr(PanelResponse, Chr(10)))
                Dim NewPacket As String = PanelResponse.Substring(InStr(PanelResponse, Chr(34)), InStr(PanelResponse, vbCr) - 2) ' Get new packet stripped of Start and Finish
                PanelResponse = Right(PanelResponse, PanelResponse.Length - NewPacket.Length - 3)
                Dim TrimChars() As Char = {Chr(34), Chr(10), Chr(13), vbCrLf}
                NewPacket.Trim(TrimChars)
                If NewPacket <> LastPacket_Crestron Then
                    ProcessPacket_Crestron(NewPacket)
                    LastPacket_Crestron = NewPacket
                End If
            Else
                AnalysisComplete = True
            End If

            If PanelResponse.Length < 5 Then AnalysisComplete = True ' Smallest packet is 7 so when we have less data we can't have a whole packet

        Loop Until AnalysisComplete
        izComLeftOverData_Crestron = PanelResponse

        ' Invalid response
        'WriteLog(ErrorLog, "Invalid Response received from panel. Response was " & PanelResponse, 0)

    End Sub
#End Region

#Region "Serial Communication Crestron"
    '    ''' <summary>
    '    ''' Send the passed string to the COM port. 
    '    ''' </summary>
    '    ''' <param name="SendStr"></param>
    '    ''' <returns></returns>
    '    ''' <remarks></remarks>


    'Friend Function SendCOMData(ByRef SendStr() As Byte) As Boolean
    ' 'send data:
    '     _rs232.SendData(SendStr)
    '
    '
    '        Return True
    '    End Function
    Friend Function OpenCOM_Crestron() As String
        WriteLog(DebugLog, "Opening COM port " & _SerPort_Crestron, 5)

        If hs.GetOSType = eOSType.linux Then
            If Not System.IO.File.Exists(_SerPort_Crestron) Then
                hs.WriteLog(IFACE_NAME, "Cannot open com port, port does not exist: " & _SerPort_Crestron)
                'gInterfaceStatus.intStatus = IPlugInAPI.enumInterfaceStatus.WARNING
                'gInterfaceStatus.sStatus = "Cannot Open Port."
                Return "Cannot open com port"
            End If
        End If
        ' now its ok to open the port
        comparams_Crestron = RS232.DefaultParams
        comparams_Crestron(RS232.cP.cPort) = _SerPort_Crestron
        comparams_Crestron(RS232.cP.cBaud) = _SerSpeed_Crestron.ToString
        comparams_Crestron(RS232.cP.cData) = _SerDataBits_Crestron.ToString
        comparams_Crestron(RS232.cP.cParity) = "None"
        comparams_Crestron(RS232.cP.cStop) = "One"

        _rs232_Crestron.connect(comparams_Crestron)

        If Not isConnected_Crestron Then
            WriteLog(ErrorLog, "Could Not connect COM port " & _SerPort_Crestron, 0)
            Return "Could Not connect"
        Else
            WriteLog(DebugLog, "Opened COM port " & _SerPort_Crestron, 3)

            ' XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
            ' SEND A HELLO COMMAND HERE
            ' XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

        End If
        Return ""
    End Function

    ''' <summary>
    '''  Do update based on data received from serial port
    ''' </summary>
    ''' <param name="buffer">received bytes from class RS232</param>
    ''' <remarks></remarks>
    Private Sub doUpdate_Crestron(ByVal buffer() As Byte) Handles _rs232_Crestron.Datareceived
        RXcount_Crestron += buffer.Length
        ' Now do something with the buffer
        WriteLog(DebugLog, "Data Received " & BytesToString(buffer), 5)
        ProcessIncomingData_Crestron(BytesToString(buffer))
    End Sub

    ''' <summary>
    ''' senda data OK NOK
    ''' </summary>
    Private Sub sendata_Crestron(ByVal sendStatus As Boolean) Handles _rs232_Crestron.sendOK
        If sendStatus Then
            ' Send OK
            WriteLog(DebugLog, "Data successfully send To COM port", 5)
        Else
            ' Send Failed
            WriteLog(ErrorLog, "Failed To send data To COM port", 0)
        End If
    End Sub

    ''' <summary>
    ''' receive successful
    ''' </summary>
    Private Sub rdata_Crestron(ByVal receiveStatus As Boolean) Handles _rs232_Crestron.recOK
        If receiveStatus Then
            ' Receive OK
        Else
            ' Receive Problem
            WriteLog(ErrorLog, "Receive Problem from COM port", 0)
        End If
    End Sub

    ''' <summary>
    '''  connection status
    ''' </summary>
    Private Sub connection_Crestron(ByVal status As Boolean) Handles _rs232_Crestron.connection
        If status Then
            ' Connected
            isConnected_Crestron = True
            WriteLog(DebugLog, "COM port Is connected", 3)
        Else
            ' Disconnected
            isConnected_Crestron = False
            WriteLog(DebugLog, "COM port Is disconnected", 3)
        End If
    End Sub

    ''' <summary>
    ''' exception message
    ''' </summary>
    Private Sub getmessage_Crestron(ByVal msg As String) Handles _rs232_Crestron.errormsg
        WriteLog(ErrorLog, "COM port Error " & msg, 0)
    End Sub
#End Region

#Region "TCP/IP Procedures Crestron"
    Private Sub izReadCallBack_Crestron(TCPIncomingMessage As String)
        Dim i As Integer = 0

        Try

            'writeLog(ErrorLog, "Bytes read: " & izTCPClient.LastReadLength.ToString, 0)
            Dim ReceiveData() As Char = izComLeftOverData_Crestron & Left(TCPIncomingMessage, izTCPClient_Crestron.LastReadLength)

            WriteLog(DebugLog, "Data Received: " & ReceiveData, 5)
            ' XXXXXXXXXXXXXXXXXXXXX
            ' DO SOMETHING WITH THE INCOMING DATA
            ' XXXXXXXXXXXXXXXXXXXXX
            ProcessIncomingData_Crestron(ReceiveData)


        Catch ex As Exception
            WriteLog(ErrorLog, "Exception from izReadCallBack: " & ex.Message, 1)
        End Try

    End Sub
    Friend Sub CloseizTCPPort_Crestron()
        WriteLog(DebugLog, "Shutting Down TCP Port ...", 5)

        Try
            izTCPClient_Crestron.Close()
            izTCPStatus_Crestron = eConnection.Closed
            WriteLog(IFACE_NAME, "TCP port successfully closed.", 0)
        Catch ex As Exception
            WriteLog(ErrorLog, "Can't close TCP port, error message: " & ex.Message, 0)
        End Try
    End Sub
    Friend Sub OpenizTCPPort_Crestron()

        If izTCPStatus_Crestron = eConnection.Open Then
            WriteLog(ErrorLog, "TCP Port already open", 1)
            Exit Sub
        End If

        Try
            WriteLog(DebugLog, "Connecting to TCP port", 3)
            izTCPClient_Crestron = New ConnectionInfo(_IPAddress_Crestron, _TCPPort_Crestron, AddressOf izReadCallBack_Crestron)

            If Not izTCPClient_Crestron.Client.Connected Then
                WriteLog(ErrorLog, "Can't connect to TCP Port: " & _TCPPort_Crestron & " at address: " & _IPAddress_Crestron, 0)
                Exit Sub
            End If

            ' Setup TCP reader
            izTCPClient_Crestron.AwaitData()

            ' Initialise communication with 
            Dim i As Integer
            WriteLog(DebugLog, "Initialising TCP communication with Texecom via TCP/IP interface ...", 5)
            If izTCPClient_Crestron.Client.Connected Then
                ' XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
                ' SEND A HELLO COMMMAND HERE
            Else
                WriteLog(ErrorLog, "Can't send initialisation packet #" & i, 0)
            End If

            izTCPStatus_Crestron = eConnection.Open
            WriteLog(DebugLog, "Texecom via TCP/IP interface communication initialisation completed", 3)

        Catch ex As Exception
            WriteLog(ErrorLog, "Exception from TCP Port Open: " & ex.Message, 0)
        End Try

    End Sub
#End Region


    ' SIMPLE PROTOCOL STUFF BELOW

#Region "izTexecom Commands Simple"
    Friend Sub SendTexecomCommand_Simple(Cmd As String)
        Try
            ' First check if it was more than 60 seconds and we need to send a login command
            If Left(Cmd, 1) <> "W" And DateDiff("s", TimeofLastSimpleCommand, Now()) > 55 Then
                Dim TempCommand As String = Cmd ' Store the current command so we can re-use after logging in
                Dim TempLastCommand As String = LastSimpleComand
                Dim LoginCommand() As Byte = StrToByteArray(_CmdStart_Simple & "W" & _UDLPassword & _CmdEnd_Simple)
                WriteLog(DebugLog, "Send Login command to Simple port", 3)
                Simple_Login()
                Cmd = TempCommand
                LastSimpleComand = TempLastCommand
                'Thread.Sleep(500)
            End If

            Dim SendStr() As Char = _CmdStart_Simple
            SendStr = _CmdStart_Simple & Cmd & _CmdEnd_Simple
            Dim SendBytes() As Byte = StrToByteArray(SendStr)

            If _UseComPort_Simple Then
                WriteLog(DebugLog, "Send command " & SendStr & StrToHexString(SendStr, False) & " via serial port", 3)
                _rs232_Simple.SendData(SendBytes)
            Else
                WriteLog(DebugLog, "Send command " & SendStr & StrToHexString(SendStr, False) & " via TCP/IP", 3)
                izTCPClient_Simple.Stream.Write(SendBytes, 0, SendBytes.Length)
            End If

            Thread.Sleep(_CommandDelay_Simple)

        Catch ex As Exception
            WriteLog(ErrorLog, "Exception from Send Command. Error ID " & ex.Message, 0)
            ' Attempt to re-open port as this is most likely the cause
            If _UseComPort_Simple Then
                _rs232_Simple.disconnect()
                OpenCOM_Simple()
            Else
                CloseizTCPPort_Simple()
                OpenizTCPPort_Simple()
            End If
        End Try
    End Sub
    Private Sub ProcessPacket_Simple(ByRef TexecomPacket As String)
        ' Valid response
        Dim DeviceNo As Integer = 0
        Dim Action As Integer = 0
        Dim dvRef As Integer = -1

        Select Case LastSimpleComand
            Case eSimpleCommmands.Login
                dvRef = hs.DeviceExistsAddress(SimpleAddress, False)
                If dvRef <> -1 Then
                    WriteLog(DebugLog, "Updating Simple Login With Status: " & TexecomPacket, 3)
                    Select Case TexecomPacket
                        Case "OK"
                            UpdateHSDeviceValue(SimpleAddress(), eSimpleDevice.LoggedIn)
                        Case "ERROR"
                            UpdateHSDeviceValue(SimpleAddress(), eSimpleDevice.Error)
                        Case Else
                            UpdateHSDeviceValue(SimpleAddress(), eSimpleDevice.Unknown)
                            WriteLog(ErrorLog, "Unknown error message when attempting Login to Simple protcol. Message was: " & TexecomPacket, 0)
                    End Select
                Else
                    WriteLog(DebugLog, "Can't update Simple Login device as device no longer exists", 3)
                End If

            Case eSimpleCommmands.Arm
                WriteLog(DebugLog, "Updating Simple Area Device With Status: " & TexecomPacket, 3)
                Select Case TexecomPacket
                    Case "OK"
                        hs.SetDeviceValueByRef(LastSimpleRef, eAreaStatus.Armed, True)
                    Case "ERROR", "NOT READY"
                        WriteLog(ErrorLog, "Can't Arm area", 0)
                    Case Else
                End Select
            Case eSimpleCommmands.Disarm, eSimpleCommmands.Reset
                WriteLog(DebugLog, "Updating Simple Area Device With Status: " & TexecomPacket, 3)
                Select Case TexecomPacket
                    Case "OK"
                        hs.SetDeviceValueByRef(LastSimpleRef, eAreaStatus.Disarmed, True)
                    Case "ERROR", "NOT READY"
                        WriteLog(ErrorLog, "Can't Disarm area", 0)
                    Case Else
                End Select
            Case eSimpleCommmands.PartArm
                WriteLog(DebugLog, "Updating Simple Area Device With Status: " & TexecomPacket, 3)
                Select Case TexecomPacket
                    Case "OK"
                        hs.SetDeviceValueByRef(LastSimpleRef, eAreaStatus.PartArmed, True)
                    Case "ERROR", "NOT READY"
                        WriteLog(ErrorLog, "Can't Part Arm area", 0)
                    Case Else
                End Select
            Case eSimpleCommmands.PanelInfo
                UpdateHSDeviceString(RootAddress, TexecomPacket)
            Case eSimpleCommmands.ReadPanelTime
                Select Case TexecomPacket
                    Case "ERROR"
                        UpdateHSDeviceString(PanelTimeAddress, "Error reading panel time")
                    Case Else
                        Try
                            Dim pTimeChars() As Char = TexecomPacket
                            Dim pDay As Integer = Asc(pTimeChars(0))
                            Dim pMonth As Integer = Asc(pTimeChars(1))
                            Dim pYear As Integer = Asc(pTimeChars(2))
                            Dim pHours As Integer = Asc(pTimeChars(3))
                            Dim pMinutes As Integer = Asc(pTimeChars(4))
                            Dim TimeString As String = Format("##", pDay) & "/" & Format("##", pMonth) & "/20" & Format("##", pYear) _
                                & "  " & Format("##", pHours) & ":" & Format("##", pMinutes)
                            UpdateHSDeviceString(PanelTimeAddress, TimeString)
                        Catch ex As Exception
                            UpdateHSDeviceString(PanelTimeAddress, "Error reading panel time")
                        End Try
                End Select
            Case eSimpleCommmands.SetPanelTime
                Select Case TexecomPacket
                    Case "ERROR"
                        UpdateHSDeviceString(PanelTimeAddress, "Error setting panel time")
                    Case "OK"
                        ' All OK
                        WriteLog(DebugLog, "Panel time sync'ed to PC time", 3)
                End Select
            Case eSimpleCommmands.ReadVoltages
                Select Case TexecomPacket
                    Case "ERROR"
                        WriteLog(ErrorLog, "Error reading voltages", 0)
                    Case Else
                        Try
                            Dim pVoltagesChars() As Char = TexecomPacket
                            Dim RB1 As Integer = Asc(pVoltagesChars(0))
                            Dim RB2 As Integer = Asc(pVoltagesChars(1))
                            Dim RB3 As Integer = Asc(pVoltagesChars(2))
                            Dim RB4 As Integer = Asc(pVoltagesChars(3))
                            Dim RB5 As Integer = Asc(pVoltagesChars(4))

                            Dim SysVolt As Double = 13.7 + ((RB2 - RB1) * 0.07)
                            UpdateHSDeviceValue(SystemVoltageAddress, SysVolt)
                            UpdateHSDeviceString(SystemVoltageAddress, Format("#0.00", SysVolt) & " V")

                            Dim BatVolt As Double = 13.7 + ((RB3 - RB1) * 0.07)
                            UpdateHSDeviceValue(BatteryVoltageAddress, BatVolt)
                            UpdateHSDeviceString(BatteryVoltageAddress, Format("#0.00", BatVolt) & " V")

                            Dim SysCur As Double = RB4 * 9 / 100
                            UpdateHSDeviceValue(SystemCurrentAddress, SysCur)
                            UpdateHSDeviceString(SystemCurrentAddress, Format("0.00", SysCur) & " A")

                            Dim BatCur As Double = RB5 * 9 / 100
                            UpdateHSDeviceValue(BatteryCurrentAddress, BatCur)
                            UpdateHSDeviceString(BatteryCurrentAddress, Format("0.00", BatCur) & " A")
                        Catch ex As Exception
                            WriteLog(ErrorLog, "Error updating voltages and current readings. Probably a corrupt packet", 0)
                        End Try
                End Select
            Case eSimpleCommmands.X10On
                Select Case TexecomPacket
                    Case "ERROR"
                        ' Update X10 device with Status Unknown
                        hs.SetDeviceValueByRef(LastSimpleRef, eX10.Unknown, True)
                        WriteLog(ErrorLog, "Can't send X10 On command for Output device: " & LastSimpleRef.ToString, 0)
                    Case "OK"
                        ' Update X10 device with Status On
                        hs.SetDeviceValueByRef(LastSimpleRef, eX10.On, True)
                End Select
            Case eSimpleCommmands.X10Off
                Select Case TexecomPacket
                    Case "ERROR"
                        ' Update X10 device with Status Unknown
                        hs.SetDeviceValueByRef(LastSimpleRef, eX10.Unknown, True)
                        WriteLog(ErrorLog, "Can't send X10 Off command for Output device: " & LastSimpleRef.ToString, 0)
                    Case "OK"
                        ' Update X10 device with Status Off
                        hs.SetDeviceValueByRef(LastSimpleRef, eX10.Off, True)
                End Select
            Case eSimpleCommmands.ReadLog
                Select Case TexecomPacket
                    Case "ERROR"
                        UpdateHSDeviceValue(PanelLogAddress, ePanelLog.Unknown)
                    Case Else
                        _PanelLogMessages(_LogIndex) = TexecomPacket
                        If Not _LogReadFromTimer Then
                            ' Update display
                            UpdateHSDeviceString(PanelLogAddress, (_LogDisplayIndex + 1).ToString & ": " & _PanelLogMessages(_LogDisplayIndex))
                        End If
                End Select
        End Select
    End Sub
    Friend Sub ProcessIncomingData_Simple(ByVal IncomingData As String)
        Dim PanelResponse As String = izComLeftOverData_Simple & IncomingData
        Dim AnalysisComplete As Boolean = False
        Do
            Dim Chr13Location As Integer = InStr(PanelResponse, Chr(13))
            Dim Chr10Location As Integer = InStr(PanelResponse, Chr(10))
            'If InStr(PanelResponse, Chr(13)) > 0 And InStr(PanelResponse, Chr(10)) > 0 Then ' We have found both end characters! 
            If Chr13Location + 1 = Chr10Location Then ' We have found both end characters! 
                Dim NewPacket As String = Left(PanelResponse, PanelResponse.Length - 2)
                PanelResponse = Right(PanelResponse, PanelResponse.Length - NewPacket.Length - 2)
                ProcessPacket_Simple(NewPacket)
            Else
                AnalysisComplete = True
                If Chr13Location > 0 Or Chr10Location > 0 Then WriteLog(DebugLog, "Chr13 found at pos. " & InStr(PanelResponse, Chr(13)) & " Chr10 found at pos " & InStr(PanelResponse, Chr(10)), 5)
            End If

            If PanelResponse.Length < 5 Then AnalysisComplete = True ' Smallest packet is 7 so when we have less data we can't have a whole packet

        Loop Until AnalysisComplete
        izComLeftOverData_Simple = PanelResponse

        ' Invalid response
        'WriteLog(ErrorLog, "Invalid Response received from panel. Response was " & PanelResponse, 0)

    End Sub
#End Region

#Region "Simple Commands"
    Private Function EncodeArea(ByVal AreaToEncode As Integer) As String
        Dim TempArea As String = Chr(AreaToEncode)
        Dim Counts As Integer = Int((AreaToEncode - 1) / 8)

        If Counts > 0 Then
            Dim i As Integer = 0
            For i = 1 To Counts
                TempArea = Chr(0) & TempArea
            Next
        End If

        Return TempArea
    End Function
    Friend Sub Simple_Login()
        LastSimpleComand = eSimpleCommmands.Login
        SendTexecomCommand_Simple("W" & _UDLPassword)
    End Sub
    Friend Sub Simple_ArmArea(ByVal AreaToArm As Integer)
        LastSimpleComand = eSimpleCommmands.Arm
        SendTexecomCommand_Simple("A" & EncodeArea(AreaToArm))
    End Sub
    Friend Sub Simple_DisarmArea(ByVal AreaToArm As Integer)
        LastSimpleComand = eSimpleCommmands.Disarm
        SendTexecomCommand_Simple("D" & EncodeArea(AreaToArm))
    End Sub
    Friend Sub Simple_PartArmArea(ByVal AreaToArm As Integer)
        LastSimpleComand = eSimpleCommmands.PartArm
        SendTexecomCommand_Simple("Y" & EncodeArea(AreaToArm))
    End Sub
    Friend Sub Simple_ResetArea(ByVal AreaToArm As Integer)
        LastSimpleComand = eSimpleCommmands.PartArm
        SendTexecomCommand_Simple("R" & EncodeArea(AreaToArm))
    End Sub
    Friend Sub Simple_PanelInfo()
        LastSimpleComand = eSimpleCommmands.PanelInfo
        'Thread.Sleep(2000)
        SendTexecomCommand_Simple("I")
    End Sub
    Friend Sub Simple_ReadPanelTime()
        LastSimpleComand = eSimpleCommmands.ReadPanelTime
        'Thread.Sleep(2000)
        SendTexecomCommand_Simple("T?")
    End Sub
    Friend Sub Simple_SetPanelTime()
        LastSimpleComand = eSimpleCommmands.SetPanelTime
        'Thread.Sleep(2000)
        Dim CommandString As String = "T"
        'CommandString = CommandString & Chr(Day(Now))
        'CommandString = CommandString & Chr(Month(Now))
        'CommandString = CommandString & Chr(Year(Now) - 2000)
        Dim ShortYr As Integer = Year(Now()) - Int(Year(Now) / 100) * 100
        CommandString = CommandString & Chr(Day(Now)) & Chr(Month(Now)) & Chr(ShortYr) & Chr(Hour(Now)) & Chr(Minute(Now))
        SendTexecomCommand_Simple(CommandString)
    End Sub
    Friend Sub Simple_ReadVoltages()
        LastSimpleComand = eSimpleCommmands.ReadVoltages
        'Thread.Sleep(2000)
        SendTexecomCommand_Simple("V")
    End Sub
    Friend Sub Simple_X10On(ByRef Output As Integer)
        LastSimpleComand = eSimpleCommmands.X10On
        Dim BitValue As Byte = 2 ^ (Output - 1)
        SendTexecomCommand_Simple("OX" & Chr(BitValue) & Chr(BitValue))
    End Sub
    Friend Sub Simple_X10Off(ByRef Output As Integer)
        LastSimpleComand = eSimpleCommmands.X10Off
        Dim BitValue As Byte = 2 ^ (Output - 1)
        SendTexecomCommand_Simple("OX" & Chr(0) & Chr(BitValue))
    End Sub
    Friend Sub Simple_PanelLogRead()
        LastSimpleComand = eSimpleCommmands.ReadLog
        For Index As Integer = 0 To _PanelLogMessages.Length - 1
            _LogIndex = Index
            SendTexecomCommand_Simple("G2" & Chr(0) & Chr(Index))
        Next
    End Sub
#End Region

#Region "Serial Communication Simple"
    '    ''' <summary>
    '    ''' Send the passed string to the COM port. 
    '    ''' </summary>
    '    ''' <param name="SendStr"></param>
    '    ''' <returns></returns>
    '    ''' <remarks></remarks>


    'Friend Function SendCOMData(ByRef SendStr() As Byte) As Boolean
    ' 'send data:
    '     _rs232.SendData(SendStr)
    '
    '
    '        Return True
    '    End Function
    Friend Function OpenCOM_Simple() As String
        WriteLog(DebugLog, "Opening COM port " & _SerPort_Simple, 5)

        If hs.GetOSType = eOSType.linux Then
            If Not System.IO.File.Exists(_SerPort_Simple) Then
                hs.WriteLog(IFACE_NAME, "Cannot open com port, port does not exist: " & _SerPort_Simple)
                'gInterfaceStatus.intStatus = IPlugInAPI.enumInterfaceStatus.WARNING
                'gInterfaceStatus.sStatus = "Cannot Open Port."
                Return "Cannot open com port"
            End If
        End If

        comparams_Simple = RS232.DefaultParams
        comparams_Simple(RS232.cP.cPort) = _SerPort_Simple
        comparams_Simple(RS232.cP.cBaud) = _SerSpeed_Simple.ToString
        comparams_Simple(RS232.cP.cData) = _SerDataBits_Simple.ToString
        comparams_Simple(RS232.cP.cParity) = "None"
        comparams_Simple(RS232.cP.cStop) = "Two"
        _rs232_Simple.connect(comparams_Simple)
        If Not isConnected_Simple Then
            WriteLog(ErrorLog, "Could Not connect COM port " & _SerPort_Simple, 0)
            Return "Could Not connect"
        Else
            WriteLog(DebugLog, "Opened COM port " & _SerPort_Simple, 3)

            ' XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
            ' SEND LOGIN COMMAND HERE
            ' XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
            Simple_Login()

        End If
        Return ""
    End Function

    ''' <summary>
    '''  Do update based on data received from serial port
    ''' </summary>
    ''' <param name="buffer">received bytes from class RS232</param>
    ''' <remarks></remarks>
    Private Sub doUpdate_Simple(ByVal buffer() As Byte) Handles _rs232_Simple.Datareceived
        RXcount_Simple += buffer.Length
        ' Now do something with the buffer
        WriteLog(DebugLog, "Data Received " & BytesToString(buffer), 5)
        ProcessIncomingData_Simple(BytesToString(buffer))
    End Sub

    ''' <summary>
    ''' senda data OK NOK
    ''' </summary>
    Private Sub sendata_Simple(ByVal sendStatus As Boolean) Handles _rs232_Simple.sendOK
        If sendStatus Then
            ' Send OK
            WriteLog(DebugLog, "Data successfully send To COM port", 5)
        Else
            ' Send Failed
            WriteLog(ErrorLog, "Failed To send data To COM port", 0)
        End If
    End Sub

    ''' <summary>
    ''' receive successful
    ''' </summary>
    Private Sub rdata_Simple(ByVal receiveStatus As Boolean) Handles _rs232_Simple.recOK
        If receiveStatus Then
            ' Receive OK
        Else
            ' Receive Problem
            WriteLog(ErrorLog, "Receive Problem from COM port", 0)
        End If
    End Sub

    ''' <summary>
    '''  connection status
    ''' </summary>
    Private Sub connection_Simple(ByVal status As Boolean) Handles _rs232_Simple.connection
        If status Then
            ' Connected
            isConnected_Simple = True
            WriteLog(DebugLog, "COM port Is connected", 3)
        Else
            ' Disconnected
            isConnected_Simple = False
            WriteLog(DebugLog, "COM port Is disconnected", 3)
        End If
    End Sub

    ''' <summary>
    ''' exception message
    ''' </summary>
    Private Sub getmessage_Simple(ByVal msg As String) Handles _rs232_Simple.errormsg
        WriteLog(ErrorLog, "COM port Error:  " & msg, 0)
    End Sub
#End Region

#Region "TCP/IP Procedures Simple"
    Private Sub izReadCallBack_Simple(TCPIncomingMessage As String)
        Dim i As Integer = 0

        Try

            'writeLog(ErrorLog, "Bytes read: " & izTCPClient.LastReadLength.ToString, 0)
            Dim ReceiveData() As Char = izComLeftOverData_Simple & Left(TCPIncomingMessage, izTCPClient_Simple.LastReadLength)

            WriteLog(DebugLog, "Data Received: " & ReceiveData, 5)
            ' XXXXXXXXXXXXXXXXXXXXX
            ' DO SOMETHING WITH THE INCOMING DATA
            ' XXXXXXXXXXXXXXXXXXXXX
            ProcessIncomingData_Simple(ReceiveData)


        Catch ex As Exception
            WriteLog(ErrorLog, "Exception from izReadCallBack: " & ex.Message, 1)
        End Try

    End Sub
    Friend Sub CloseizTCPPort_Simple()
        WriteLog(DebugLog, "Shutting Down TCP Port ...", 5)

        Try
            izTCPClient_Simple.Close()
            izTCPStatus_Simple = eConnection.Closed
            WriteLog(IFACE_NAME, "TCP port successfully closed.", 0)
        Catch ex As Exception
            WriteLog(ErrorLog, "Can't close TCP port, error message: " & ex.Message, 0)
        End Try
    End Sub
    Friend Sub OpenizTCPPort_Simple()

        If izTCPStatus_Simple = eConnection.Open Then
            WriteLog(ErrorLog, "TCP Port already open", 1)
            Exit Sub
        End If

        Try
            WriteLog(DebugLog, "Connecting to TCP port", 3)
            izTCPClient_Simple = New ConnectionInfo(_IPAddress_Simple, _TCPPort_Simple, AddressOf izReadCallBack_Simple)

            If Not izTCPClient_Simple.Client.Connected Then
                WriteLog(ErrorLog, "Can't connect to TCP Port: " & _TCPPort_Simple & " at address: " & _IPAddress_Simple, 0)
                Exit Sub
            End If

            ' Setup TCP reader
            izTCPClient_Simple.AwaitData()

            ' Initialise communication with 
            Dim i As Integer
            WriteLog(DebugLog, "Initialising TCP communication with Texecom via TCP/IP interface ...", 5)
            If izTCPClient_Simple.Client.Connected Then
                ' XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
                ' SEND A HELLO COMMMAND HERE
            Else
                WriteLog(ErrorLog, "Can't send initialisation packet #" & i, 0)
            End If

            izTCPStatus_Simple = eConnection.Open
            WriteLog(DebugLog, "Texecom via TCP/IP interface communication initialisation completed", 3)

        Catch ex As Exception
            WriteLog(ErrorLog, "Exception from TCP Port Open: " & ex.Message, 0)
        End Try

    End Sub
#End Region


End Module
