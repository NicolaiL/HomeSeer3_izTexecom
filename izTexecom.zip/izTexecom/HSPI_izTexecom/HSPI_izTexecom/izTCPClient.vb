﻿Imports System.Net
Imports System.Net.Sockets

'Encapuslates the client connection and provides a state object for async read operations
Public Class ConnectionInfo
    Const BufferSize As Integer = 1024 ' Sets the buffer size used in this Class


    Private _AppendMethod As Action(Of String)
    Public ReadOnly Property AppendMethod As Action(Of String)
        Get
            Return _AppendMethod
        End Get
    End Property

    Private _Client As TcpClient
    Public ReadOnly Property Client As TcpClient
        Get
            Return _Client
        End Get
    End Property

    Private _Stream As NetworkStream
    Public ReadOnly Property Stream As NetworkStream
        Get
            Return _Stream
        End Get
    End Property

    Private _LastReadLength As Integer
    Public ReadOnly Property LastReadLength As Integer
        Get
            Return _LastReadLength
        End Get
    End Property

    Private _Buffer(BufferSize - 1) As Byte

    Public Sub New(address As String, port As Integer, append As Action(Of String))
        Try
            _AppendMethod = append
            _Client = New TcpClient
            _Client.Connect(address, port)
            _Stream = _Client.GetStream
        Catch ex As Exception
            Console.WriteLine(ex.Message)
        End Try
        
    End Sub

    Public Sub AwaitData()
        Try
            _Stream.BeginRead(_Buffer, 0, _Buffer.Length, AddressOf DoReadData, Me)
        Catch ex As Exception

        End Try

    End Sub

    Public Sub Close()
        If _Client IsNot Nothing Then _Client.Close()
        _Client = Nothing
        _Stream = Nothing
    End Sub

    Private Sub DoReadData(result As IAsyncResult)
        Dim info As ConnectionInfo = CType(result.AsyncState, ConnectionInfo)
        Try
            If info._Stream IsNot Nothing AndAlso info._Stream.CanRead Then
                info._LastReadLength = info._Stream.EndRead(result)
                If info._LastReadLength > 0 Then
                    'Dim message As String = System.Text.Encoding.ASCII.GetString(info._Buffer)
                    Dim message As String = BytesToString(info._Buffer)
                    info._AppendMethod(message)
                End If
                info.AwaitData()
            End If
        Catch ex As Exception
            info._LastReadLength = -1
            info._AppendMethod(ex.Message)
        End Try
    End Sub

    Private Function BytesToString(ByVal data() As Byte) As String
        BytesToString = ""
        Dim i As Integer
        For i = 0 To data.Length - 1
            BytesToString += Chr(data(i))
        Next
    End Function

End Class