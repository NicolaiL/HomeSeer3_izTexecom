// JavaScript source code
// <script>
function ShowSelector() {
    $("#mysel_normal").removeClass();
    $("#mysel_selected").removeClass();
    $("#mysel_normal").attr("style", "width:400px");
    $("#mysel_normal").attr("size", "20");
    $("#mysel_selected").attr("style", "width:400px");
    $("#mysel_selected").attr("size", "20");
}


$(document).ready(function() {
    $("#mysel_normal").removeClass();
    $("#mysel_selected").removeClass();
    $("#mysel_normal").attr("style", "width:400px");
    $("#mysel_normal").attr("size", "20");
    $("#mysel_selected").attr("style", "width:400px");
    $("#mysel_selected").attr("size", "20"); })
  //     </script>

